import { db } from "../firebase";
import {
  collection,
  doc,
  getDoc,
  getDocs,
  limit,
  orderBy,
  query,
  serverTimestamp,
  where,
  writeBatch,
} from "firebase/firestore";

function normalizeTitle(title) {
  return String(title ?? "").trim();
}

function normalizeTitleLower(title) {
  return normalizeTitle(title).toLowerCase();
}

function toFiniteNumber(value, fallback = 0) {
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}

export function buildSharedSaveDocuments({ saveEntry, ownerUid, ownerUsername, title }) {
  const cleanTitle = normalizeTitle(title);
  if (!cleanTitle) {
    throw new Error("Save title must not be empty.");
  }

  const stats = saveEntry?.tree?.stats ?? {};
  const minimum = stats.minimum ?? {};
  const final = stats.final ?? {};

  const metadata = {
    ownerUid,
    ownerUsername: String(ownerUsername ?? ""),
    title: cleanTitle,
    titleLower: cleanTitle.toLowerCase(),

    uploadedAt: serverTimestamp(),
    updatedAt: serverTimestamp(),

    saveVersion: toFiniteNumber(saveEntry?.version, 2),
    isPublic: true,

    minMoney: toFiniteNumber(minimum.money),
    minSupplies: toFiniteNumber(minimum.supplies),
    minGoods: toFiniteNumber(minimum.goods),
    minTroops: toFiniteNumber(minimum.troops),
    minCoinBoost: toFiniteNumber(minimum.coinBoost),
    minSupplyBoost: toFiniteNumber(minimum.supplyBoost),
    minShardsUsed: toFiniteNumber(minimum.shardsUsed),

    finalAttack: toFiniteNumber(final.attack),
    finalDefense: toFiniteNumber(final.defense),
    finalTotalQaSetup: toFiniteNumber(final.totalQaSetup),
  };

  const payload = {
    ownerUid,
    version: toFiniteNumber(saveEntry?.version, 2),
    name: cleanTitle,
    tree: saveEntry?.tree ?? null,
    saveConfig: saveEntry?.saveConfig ?? null,
    stats: {
      minimum: {
        money: toFiniteNumber(minimum.money),
        supplies: toFiniteNumber(minimum.supplies),
        goods: toFiniteNumber(minimum.goods),
        troops: toFiniteNumber(minimum.troops),
        coinBoost: toFiniteNumber(minimum.coinBoost),
        supplyBoost: toFiniteNumber(minimum.supplyBoost),
        shardsUsed: toFiniteNumber(minimum.shardsUsed),
      },
      final: {
        attack: toFiniteNumber(final.attack),
        defense: toFiniteNumber(final.defense),
        totalQaSetup: toFiniteNumber(final.totalQaSetup),
      },
    },
  };

  return { metadata, payload };
}

export async function findOwnSharedSaveByTitle({ ownerUid, title }) {
  const cleanLower = normalizeTitleLower(title);
  if (!ownerUid || !cleanLower) return null;

  const q = query(
    collection(db, "sharedSaves"),
    where("ownerUid", "==", ownerUid),
    where("titleLower", "==", cleanLower),
    limit(1),
  );

  const snap = await getDocs(q);
  if (snap.empty) return null;

  const first = snap.docs[0];
  return {
    id: first.id,
    ...first.data(),
  };
}

export async function uploadSharedSave({ saveEntry, ownerUid, ownerUsername, title }) {
  if (!ownerUid) throw new Error("Missing ownerUid.");

  const { metadata, payload } = buildSharedSaveDocuments({
    saveEntry,
    ownerUid,
    ownerUsername,
    title,
  });

  const metaRef = doc(collection(db, "sharedSaves"));
  const payloadRef = doc(db, "sharedSaves", metaRef.id, "data", "content");

  const batch = writeBatch(db);
  batch.set(metaRef, metadata);
  batch.set(payloadRef, payload);

  await batch.commit();

  return metaRef.id;
}

export async function overwriteSharedSave({
  saveId,
  saveEntry,
  ownerUid,
  ownerUsername,
  title,
}) {
  if (!saveId) throw new Error("Missing saveId.");
  if (!ownerUid) throw new Error("Missing ownerUid.");

  const { metadata, payload } = buildSharedSaveDocuments({
    saveEntry,
    ownerUid,
    ownerUsername,
    title,
  });

  const metaRef = doc(db, "sharedSaves", saveId);
  const payloadRef = doc(db, "sharedSaves", saveId, "data", "content");

  const existingMetaSnap = await getDoc(metaRef);
  if (!existingMetaSnap.exists()) {
    throw new Error("Shared save not found.");
  }

  const existingMeta = existingMetaSnap.data();
  if (existingMeta.ownerUid !== ownerUid) {
    throw new Error("You are not allowed to overwrite this save.");
  }

  const batch = writeBatch(db);
  batch.set(metaRef, {
    ...metadata,
    uploadedAt: existingMeta.uploadedAt ?? serverTimestamp(),
    updatedAt: serverTimestamp(),
  });
  batch.set(payloadRef, payload);

  await batch.commit();
}

export async function renameSharedSave({ saveId, ownerUid, newTitle }) {
  const cleanTitle = normalizeTitle(newTitle);
  if (!saveId) throw new Error("Missing saveId.");
  if (!ownerUid) throw new Error("Missing ownerUid.");
  if (!cleanTitle) throw new Error("New title must not be empty.");

  const metaRef = doc(db, "sharedSaves", saveId);
  const payloadRef = doc(db, "sharedSaves", saveId, "data", "content");

  const metaSnap = await getDoc(metaRef);
  if (!metaSnap.exists()) throw new Error("Shared save not found.");

  const meta = metaSnap.data();
  if (meta.ownerUid !== ownerUid) {
    throw new Error("You are not allowed to rename this save.");
  }

  const batch = writeBatch(db);
  batch.update(metaRef, {
    title: cleanTitle,
    titleLower: cleanTitle.toLowerCase(),
    updatedAt: serverTimestamp(),
  });
  batch.update(payloadRef, {
    name: cleanTitle,
  });

  await batch.commit();
}

export async function deleteSharedSave({ saveId, ownerUid }) {
  if (!saveId) throw new Error("Missing saveId.");
  if (!ownerUid) throw new Error("Missing ownerUid.");

  const metaRef = doc(db, "sharedSaves", saveId);
  const payloadRef = doc(db, "sharedSaves", saveId, "data", "content");

  const metaSnap = await getDoc(metaRef);
  if (!metaSnap.exists()) return;

  const meta = metaSnap.data();
  if (meta.ownerUid !== ownerUid) {
    throw new Error("You are not allowed to delete this save.");
  }

  const batch = writeBatch(db);
  batch.delete(payloadRef);
  batch.delete(metaRef);

  await batch.commit();
}

export async function downloadSharedSave(saveId) {
  if (!saveId) throw new Error("Missing saveId.");

  const payloadRef = doc(db, "sharedSaves", saveId, "data", "content");
  const payloadSnap = await getDoc(payloadRef);

  if (!payloadSnap.exists()) {
    throw new Error("Shared save payload not found.");
  }

  return payloadSnap.data();
}

export async function listNewestSharedSaves(pageSize = 25) {
  const q = query(
    collection(db, "sharedSaves"),
    where("isPublic", "==", true),
    orderBy("uploadedAt", "desc"),
    limit(pageSize),
  );

  const snap = await getDocs(q);
  return snap.docs.map((d) => ({
    id: d.id,
    ...d.data(),
  }));
}

export async function syncOwnerUsernameOnSharedSaves({ ownerUid, newUsername }) {
  if (!ownerUid) throw new Error("Missing ownerUid.");

  const q = query(
    collection(db, "sharedSaves"),
    where("ownerUid", "==", ownerUid),
  );

  const snap = await getDocs(q);
  if (snap.empty) return 0;

  let updated = 0;
  let batch = writeBatch(db);
  let ops = 0;

  for (const sharedSaveDoc of snap.docs) {
    batch.update(sharedSaveDoc.ref, {
      ownerUsername: String(newUsername ?? ""),
      updatedAt: serverTimestamp(),
    });
    ops += 1;
    updated += 1;

    if (ops === 400) {
      await batch.commit();
      batch = writeBatch(db);
      ops = 0;
    }
  }

  if (ops > 0) {
    await batch.commit();
  }

  return updated;
}
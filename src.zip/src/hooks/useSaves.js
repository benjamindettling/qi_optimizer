import { useEffect, useState } from "react";

const STORAGE_KEY = "qi_saves";

export function useSaves() {
  const [saves, setSaves] = useState({});
  const [loadName, setLoadName] = useState("");
  const [savesLoaded, setSavesLoaded] = useState(false);

  useEffect(() => {
    const savedRaw = localStorage.getItem(STORAGE_KEY);
    if (savedRaw) {
      try {
        const parsed = JSON.parse(savedRaw);
        const filtered = Object.fromEntries(
          Object.entries(parsed || {}).filter(
            ([, entry]) => !entry?.meta?.isSnapshot
          )
        );
        setSaves(filtered);
        // Clean out hidden snapshots on load so they don't persist across refreshes.
        if (Object.keys(filtered).length !== Object.keys(parsed || {}).length) {
          localStorage.setItem(STORAGE_KEY, JSON.stringify(filtered));
        }
      } catch (e) {
        console.error("Failed to parse saves", e);
      }
    }
    setSavesLoaded(true);
  }, []);

  const stripSignaturesInSaves = (obj = {}) => {
    const next = {};
    for (const [name, entry] of Object.entries(obj)) {
      const cps = entry.checkpoints || [];
      next[name] = {
        ...entry,
        checkpoints: cps.map(({ signature, ...rest }) => rest),
      };
    }
    return next;
  };

  const persist = (obj) => {
    const cleaned = stripSignaturesInSaves(obj || {});
    setSaves(cleaned);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(cleaned));
  };

  const setAllSaves = (updater) => {
    setSaves((prev) => {
      const next = typeof updater === "function" ? updater(prev) : updater;
      const finalObj = next || {};
      localStorage.setItem(STORAGE_KEY, JSON.stringify(finalObj));
      return finalObj;
    });
  };

  const saveSnapshot = (name, payload) => {
    if (!name) return;
    const entry = payload && payload.snapshot ? payload : { snapshot: payload };
    setAllSaves((prev) => ({ ...prev, [name]: entry }));
  };

  const loadSnapshot = (name) => saves[name] ?? null;

  const deleteSave = (name) => {
    const next = { ...saves };
    delete next[name];
    persist(next);
  };

  return {
    saves,
    loadName,
    setLoadName,
    savesLoaded,
    setAllSaves,
    saveSnapshot,
    loadSnapshot,
    deleteSave,
  };
}

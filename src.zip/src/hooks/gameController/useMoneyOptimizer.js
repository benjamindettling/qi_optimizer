import { useCallback, useEffect, useRef, useState } from "react";
import { BOARD_HEIGHT, BOARD_WIDTH } from "../../config/boardConfig";
import { happinessTier } from "../../utils/gameMath";
import { solveTilingMask } from "../../utils/tilingSolver";
import { buildTilingGroups, buildTilingMask } from "../../utils/tilingTranslator";
import { normalizeOptimizerInstance } from "./useSupplyOptimizer";

const DEF_IDS = {
  MH: "housing:mehrgeschossiges_haus",
  EH: "housing:gutshaus",
  CHURCH: "culture:kirche",
  BREWERY: "production:brauerei",
};

const BASE_MH = 12500;
const BASE_EH = 3750;

const initialOptimizerState = {
  running: false,
  phase: "idle",
  subPhase: "geometry",
  geomEvalCount: 0,
  harvestEvalCount: 0,
  currentSetup: null,
  bestSetup: null,
  finalResources: null,
};

const toNumber = (value) => (Number.isFinite(Number(value)) ? Number(value) : 0);

const cloneResources = (resources) => ({
  coins: toNumber(resources?.coins),
  supplies: toNumber(resources?.supplies),
  chronos: toNumber(resources?.chronos),
});

const cloneLayout = (layout, libraryMap) =>
  (layout || [])
    .map((instance) => normalizeOptimizerInstance(instance, libraryMap))
    .filter(Boolean)
    .map((instance) => ({ ...instance }));

const countDefId = (layout, defId) =>
  (layout || []).reduce(
    (count, instance) => count + (instance.defId === defId ? 1 : 0),
    0,
  );

const getStats = (layout, libraryMap) => {
  let totalPeople = 0;
  let totalPeopleReq = 0;
  let happinessProvided = 0;
  (layout || []).forEach((instance) => {
    const def = libraryMap?.[instance.defId];
    if (!def) return;
    totalPeople += toNumber(def.people);
    totalPeopleReq += toNumber(def.requiresPeople);
    happinessProvided += toNumber(def.happiness);
  });
  const happinessRequired = Math.max(totalPeopleReq, totalPeople);
  return { totalPeople, totalPeopleReq, happinessProvided, happinessRequired };
};

const runFitsCheck = (mask, layout) => {
  const { blocks } = buildTilingGroups(layout, []);
  const placements = solveTilingMask(mask, blocks, { allowGaps: true });
  return placements !== null;
};

const addInstance = (ctx, layout, defId) => {
  const def = ctx.defById[defId];
  if (!def) return null;
  const instance = {
    id: ctx.syntheticNextId++,
    defId,
    width: toNumber(def.size?.[0]) || toNumber(def.width),
    height: toNumber(def.size?.[1]) || toNumber(def.height),
  };
  layout.push(instance);
  return instance;
};

const removeOneByDefId = (layout, defId) => {
  for (let i = layout.length - 1; i >= 0; i -= 1) {
    if (layout[i].defId === defId) {
      return layout.splice(i, 1)[0];
    }
  }
  return null;
};

const cloneMoneySetup = (setup) => (setup ? { ...setup } : null);

const waitNextTick = () =>
  new Promise((resolve) => {
    setTimeout(resolve, 0);
  });

const makeRunContext = ({
  supplyResultLayout,
  supplyResultResources,
  preExistingLayout,
  libraryMap,
  isCellUnlockedFn,
  nextIdRef,
}) => {
  const normalizedSupplyLayout = cloneLayout(supplyResultLayout, libraryMap);
  const normalizedPreExisting = cloneLayout(preExistingLayout, libraryMap);
  const supplyResources = cloneResources(supplyResultResources);
  if (!supplyResultResources) {
    return { done: true, finalResources: null };
  }

  const mhDef = libraryMap?.[DEF_IDS.MH];
  const ehDef = libraryMap?.[DEF_IDS.EH];
  const churchDef = libraryMap?.[DEF_IDS.CHURCH];
  const breweryDef = libraryMap?.[DEF_IDS.BREWERY];

  const maxExistingId = [...normalizedSupplyLayout, ...normalizedPreExisting].reduce(
    (maxId, instance) => Math.max(maxId, toNumber(instance.id)),
    0,
  );

  const ctx = {
    libraryMap,
    mask: buildTilingMask(BOARD_WIDTH, BOARD_HEIGHT, isCellUnlockedFn),
    supplyResultLayout: normalizedSupplyLayout,
    preExistingLayout: normalizedPreExisting,
    supplyResultResources: supplyResources,
    loopResources: cloneResources(supplyResources),
    defById: {
      [DEF_IDS.MH]: mhDef,
      [DEF_IDS.EH]: ehDef,
      [DEF_IDS.CHURCH]: churchDef,
      [DEF_IDS.BREWERY]: breweryDef,
    },
    syntheticNextId: Math.max(toNumber(nextIdRef?.current) || 1, maxExistingId + 1),
    geometryBaseLayout: [],
    geometryLayout: [],
    geometryMhCount: 0,
    geometryChurchCount: 0,
    geometryMode: "fill",
    maxHousingSlots: [],
    maxSlots: 0,
    harvestEhOffset: 0,
    noImproveStreak: 0,
    bestMoneyHarvest: Number.NEGATIVE_INFINITY,
    bestSetup: null,
    currentSetup: null,
    finalResources: null,
    subPhase: "geometry",
    done: false,
    priorMH: countDefId(normalizedPreExisting, DEF_IDS.MH),
    priorEH: countDefId(normalizedPreExisting, DEF_IDS.EH),
    finalMH: countDefId(normalizedSupplyLayout, DEF_IDS.MH),
    finalEH: countDefId(normalizedSupplyLayout, DEF_IDS.EH),
    finalChurches: countDefId(normalizedSupplyLayout, DEF_IDS.CHURCH),
  };

  if (!mhDef || !ehDef || !churchDef || !breweryDef) {
    ctx.done = true;
    return ctx;
  }

  const churchCost = toNumber(churchDef.cost?.coins);
  const breweryCost = toNumber(breweryDef.cost?.coins);

  ctx.geometryBaseLayout = normalizedSupplyLayout
    .filter((instance) => {
      if (instance.defId === DEF_IDS.CHURCH) {
        ctx.loopResources.coins -= churchCost;
        return false;
      }
      if (instance.defId === DEF_IDS.BREWERY) {
        ctx.loopResources.coins -= breweryCost;
        return false;
      }
      // MH/EH are the optimization variables in phase 2 and are rebuilt each iteration.
      if (instance.defId === DEF_IDS.MH || instance.defId === DEF_IDS.EH) {
        return false;
      }
      return true;
    })
    .map((instance) => ({ ...instance }));

  ctx.geometryLayout = ctx.geometryBaseLayout.map((instance) => ({ ...instance }));
  ctx.geometryMhCount = countDefId(ctx.geometryLayout, DEF_IDS.MH);

  return ctx;
};

const runGeometryStep = (ctx, countersRef) => {
  if (ctx.subPhase !== "geometry" || ctx.done) return;

  if (ctx.geometryMode === "fill") {
    addInstance(ctx, ctx.geometryLayout, DEF_IDS.MH);
    const fits = runFitsCheck(ctx.mask, ctx.geometryLayout);
    countersRef.current.geomEvalCount += 1;
    if (fits) {
      ctx.geometryMhCount += 1;
      return;
    }
    removeOneByDefId(ctx.geometryLayout, DEF_IDS.MH);
    ctx.maxHousingSlots[0] = ctx.geometryMhCount;
    ctx.maxSlots = ctx.geometryMhCount;
    ctx.geometryMode = "swap";
    return;
  }

  ctx.geometryChurchCount += 1;
  addInstance(ctx, ctx.geometryLayout, DEF_IDS.CHURCH);
  let swapFits = runFitsCheck(ctx.mask, ctx.geometryLayout);
  countersRef.current.geomEvalCount += 1;

  while (!swapFits && ctx.geometryMhCount > 0) {
    const removedMh = removeOneByDefId(ctx.geometryLayout, DEF_IDS.MH);
    if (!removedMh) break;
    ctx.geometryMhCount -= 1;
    swapFits = runFitsCheck(ctx.mask, ctx.geometryLayout);
    countersRef.current.geomEvalCount += 1;
  }

  ctx.maxHousingSlots[ctx.geometryChurchCount] = ctx.geometryMhCount;
  if (ctx.geometryMhCount === 0) {
    ctx.subPhase = "harvest";
    ctx.harvestEhOffset = 0;
    if (ctx.maxSlots === 0) {
      ctx.finalResources = {
        coins: ctx.supplyResultResources.coins,
        supplies: ctx.supplyResultResources.supplies,
        chronos: ctx.supplyResultResources.chronos,
      };
      ctx.done = true;
    }
  }
};

const runHarvestIteration = (ctx, countersRef) => {
  if (ctx.done || ctx.subPhase !== "harvest") return;

  if (ctx.harvestEhOffset > ctx.maxSlots) {
    ctx.done = true;
    const bestMoneyHarvest = Number.isFinite(ctx.bestMoneyHarvest)
      ? ctx.bestMoneyHarvest
      : 0;
    ctx.finalResources = {
      coins: ctx.supplyResultResources.coins + bestMoneyHarvest,
      supplies: ctx.supplyResultResources.supplies,
      chronos: ctx.supplyResultResources.chronos,
    };
    return;
  }

  const start_MH = ctx.maxSlots - ctx.harvestEhOffset;
  const start_EH = ctx.harvestEhOffset;

  const workingResources = cloneResources(ctx.loopResources);
  const workingLayout = cloneLayout(ctx.geometryBaseLayout, ctx.libraryMap);

  for (let i = 0; i < start_MH; i += 1) {
    addInstance(ctx, workingLayout, DEF_IDS.MH);
  }
  for (let i = 0; i < start_EH; i += 1) {
    addInstance(ctx, workingLayout, DEF_IDS.EH);
  }

  const mhCost = toNumber(ctx.defById[DEF_IDS.MH]?.cost?.coins);
  const ehCost = toNumber(ctx.defById[DEF_IDS.EH]?.cost?.coins);
  const churchCost = toNumber(ctx.defById[DEF_IDS.CHURCH]?.cost?.coins);

  const mhSell = Math.floor(mhCost * 0.25);
  const ehSell = Math.floor(ehCost * 0.25);
  const churchSell = Math.floor(churchCost * 0.25);

  const mhDiff = start_MH - ctx.priorMH;
  if (mhDiff > 0) workingResources.coins -= mhDiff * mhCost;
  if (mhDiff < 0) workingResources.coins += Math.abs(mhDiff) * mhSell;

  const ehDiff = start_EH - ctx.priorEH;
  if (ehDiff > 0) workingResources.coins -= ehDiff * ehCost;
  if (ehDiff < 0) workingResources.coins += Math.abs(ehDiff) * ehSell;

  let numb_MH = start_MH;
  let numb_EH = start_EH;
  let c = 1;
  let numb_churches = 0;

  while (true) {
    const stats = getStats(workingLayout, ctx.libraryMap);
    const happyEnough =
      stats.happinessProvided >= 2 * stats.happinessRequired;
    if (happyEnough) {
      const happiness_boost = happinessTier(
        stats.happinessProvided,
        stats.happinessRequired,
      ).ratio;

      const money_from_remaining =
        BASE_MH * numb_MH * (numb_EH * 0.2 + happiness_boost) +
        BASE_EH * numb_EH * (numb_EH * 0.2 + happiness_boost);

      let buildingDiff = 0;
      if (numb_MH > ctx.finalMH) {
        buildingDiff += (numb_MH - ctx.finalMH) * mhSell;
      } else if (numb_MH < ctx.finalMH) {
        buildingDiff -= (ctx.finalMH - numb_MH) * mhCost;
      }

      if (numb_EH > ctx.finalEH) {
        buildingDiff += (numb_EH - ctx.finalEH) * ehSell;
      } else if (numb_EH < ctx.finalEH) {
        buildingDiff -= (ctx.finalEH - numb_EH) * ehCost;
      }

      if (numb_churches > ctx.finalChurches) {
        buildingDiff += (numb_churches - ctx.finalChurches) * churchSell;
      } else if (numb_churches < ctx.finalChurches) {
        buildingDiff -= (ctx.finalChurches - numb_churches) * churchCost;
      }

      const total_coins_this_iteration =
        workingResources.coins + money_from_remaining + buildingDiff;
      const moneyHarvest = total_coins_this_iteration - ctx.loopResources.coins;

      ctx.currentSetup = {
        start_MH,
        start_EH,
        numb_churches,
        moneyHarvest,
      };

      if (ctx.bestSetup === null || moneyHarvest > ctx.bestMoneyHarvest) {
        ctx.bestMoneyHarvest = moneyHarvest;
        ctx.bestSetup = cloneMoneySetup(ctx.currentSetup);
        ctx.noImproveStreak = 0;
      } else {
        ctx.noImproveStreak += 1;
      }

      countersRef.current.harvestEvalCount += 1;
      ctx.harvestEhOffset += 1;

      if (ctx.noImproveStreak >= 2 || ctx.harvestEhOffset > ctx.maxSlots) {
        ctx.done = true;
        const bestMoneyHarvest = Number.isFinite(ctx.bestMoneyHarvest)
          ? ctx.bestMoneyHarvest
          : 0;
        ctx.finalResources = {
          coins: ctx.supplyResultResources.coins + bestMoneyHarvest,
          supplies: ctx.supplyResultResources.supplies,
          chronos: ctx.supplyResultResources.chronos,
        };
      }
      return;
    }

    const currentHousingCount = numb_MH + numb_EH;
    const threshold = ctx.maxHousingSlots[c] ?? 0;
    if (currentHousingCount === threshold) {
      workingResources.coins -= churchCost;
      addInstance(ctx, workingLayout, DEF_IDS.CHURCH);
      numb_churches += 1;
      c += 1;
      continue;
    }

    const happiness_boost = happinessTier(
      stats.happinessProvided,
      stats.happinessRequired,
    ).ratio;

    if (numb_MH > 0) {
      workingResources.coins += BASE_MH * (numb_EH * 0.2 + happiness_boost);
      workingResources.coins += mhSell;
      removeOneByDefId(workingLayout, DEF_IDS.MH);
      numb_MH -= 1;
      continue;
    }

    if (numb_EH > 0) {
      workingResources.coins += BASE_EH * (numb_EH * 0.2 + happiness_boost);
      workingResources.coins += ehSell;
      removeOneByDefId(workingLayout, DEF_IDS.EH);
      numb_EH -= 1;
      continue;
    }

    // Safety: if no housing remains and threshold logic cannot progress, buy church.
    workingResources.coins -= churchCost;
    addInstance(ctx, workingLayout, DEF_IDS.CHURCH);
    numb_churches += 1;
    c += 1;
  }
};

export const useMoneyOptimizer = ({
  supplyResultLayout,
  supplyResultResources,
  preExistingLayout,
  libraryMap,
  isCellUnlockedFn,
  nextIdRef,
}) => {
  const [optimizerState, setOptimizerState] = useState(initialOptimizerState);

  const inputRef = useRef({
    supplyResultLayout,
    supplyResultResources,
    preExistingLayout,
    libraryMap,
    isCellUnlockedFn,
    nextIdRef,
  });
  const contextRef = useRef(null);
  const runningRef = useRef(false);
  const countersRef = useRef({
    geomEvalCount: 0,
    harvestEvalCount: 0,
  });
  const liveCounterTimerRef = useRef(null);

  useEffect(() => {
    inputRef.current = {
      supplyResultLayout,
      supplyResultResources,
      preExistingLayout,
      libraryMap,
      isCellUnlockedFn,
      nextIdRef,
    };
  }, [
    supplyResultLayout,
    supplyResultResources,
    preExistingLayout,
    libraryMap,
    isCellUnlockedFn,
    nextIdRef,
  ]);

  useEffect(
    () => () => {
      if (liveCounterTimerRef.current) {
        clearInterval(liveCounterTimerRef.current);
        liveCounterTimerRef.current = null;
      }
    },
    [],
  );

  const ensureContext = useCallback(() => {
    if (contextRef.current && !contextRef.current.done) {
      return { context: contextRef.current, createdNew: false };
    }
    const nextContext = makeRunContext(inputRef.current);
    contextRef.current = nextContext;
    return { context: nextContext, createdNew: true };
  }, []);

  const applyPausedOrDoneState = useCallback((phase) => {
    const context = contextRef.current;
    setOptimizerState((prev) => ({
      ...prev,
      running: false,
      phase,
      subPhase: context?.subPhase ?? prev.subPhase,
      geomEvalCount: countersRef.current.geomEvalCount,
      harvestEvalCount: countersRef.current.harvestEvalCount,
      currentSetup: cloneMoneySetup(context?.currentSetup) || prev.currentSetup,
      bestSetup: cloneMoneySetup(context?.bestSetup) || prev.bestSetup,
      finalResources: context?.finalResources
        ? { ...context.finalResources }
        : prev.finalResources,
    }));
  }, []);

  const runMode = useCallback(
    async (mode) => {
      if (runningRef.current) return;

      const { context, createdNew } = ensureContext();
      if (!context || !context.supplyResultResources) return;

      countersRef.current = { geomEvalCount: 0, harvestEvalCount: 0 };
      runningRef.current = true;

      setOptimizerState((prev) => ({
        ...prev,
        running: true,
        phase: "running",
        subPhase: context.subPhase,
        geomEvalCount: 0,
        harvestEvalCount: 0,
        currentSetup: createdNew ? null : prev.currentSetup,
        bestSetup: createdNew ? null : prev.bestSetup,
        finalResources: createdNew ? null : prev.finalResources,
      }));

      if (liveCounterTimerRef.current) {
        clearInterval(liveCounterTimerRef.current);
      }
      liveCounterTimerRef.current = setInterval(() => {
        setOptimizerState((prev) =>
          prev.phase !== "running"
            ? prev
            : {
                ...prev,
                subPhase: contextRef.current?.subPhase ?? prev.subPhase,
                geomEvalCount: countersRef.current.geomEvalCount,
                harvestEvalCount: countersRef.current.harvestEvalCount,
              },
        );
      }, 200);

      try {
        let shouldPause = false;

        while (!context.done) {
          if (context.subPhase === "geometry") {
            runGeometryStep(context, countersRef);
            if (mode === "once") {
              shouldPause = true;
            } else if (mode === "few" && context.subPhase === "harvest") {
              shouldPause = true;
            }
          } else {
            runHarvestIteration(context, countersRef);
            if (mode === "once" && !context.done) {
              shouldPause = true;
            }
          }

          if (context.done || shouldPause) break;
          await waitNextTick();
        }

        if (context.done) {
          applyPausedOrDoneState("done");
        } else {
          applyPausedOrDoneState("paused");
        }
      } finally {
        runningRef.current = false;
        if (liveCounterTimerRef.current) {
          clearInterval(liveCounterTimerRef.current);
          liveCounterTimerRef.current = null;
        }
      }
    },
    [applyPausedOrDoneState, ensureContext],
  );

  const startFromSupplyResult = useCallback(
    (payload, triggerMode = "finish") => {
      inputRef.current = {
        ...inputRef.current,
        supplyResultLayout: payload?.supplyResultLayout || [],
        supplyResultResources: payload?.supplyResultResources || null,
        preExistingLayout:
          payload?.preExistingLayout || inputRef.current.preExistingLayout || [],
      };
      contextRef.current = null;
      setOptimizerState(initialOptimizerState);

      const mappedMode =
        triggerMode === "once" || triggerMode === "few" || triggerMode === "finish"
          ? triggerMode
          : "finish";
      queueMicrotask(() => {
        runMode(mappedMode);
      });
    },
    [runMode],
  );

  const stepOnce = useCallback(() => runMode("once"), [runMode]);
  const stepFew = useCallback(() => runMode("few"), [runMode]);
  const finish = useCallback(() => runMode("finish"), [runMode]);
  const reset = useCallback(() => {
    contextRef.current = null;
    countersRef.current = { geomEvalCount: 0, harvestEvalCount: 0 };
    runningRef.current = false;
    if (liveCounterTimerRef.current) {
      clearInterval(liveCounterTimerRef.current);
      liveCounterTimerRef.current = null;
    }
    setOptimizerState(initialOptimizerState);
  }, []);

  return {
    optimizerState,
    startFromSupplyResult,
    stepOnce,
    stepFew,
    finish,
    reset,
  };
};

import { createContext, useCallback, useContext, useMemo, useState } from "react";
import {
  MH_TARGET_SLOTS,
  TUTORIAL_STEPS,
  TUTORIAL_EXAMPLE_SAVE_NAME,
} from "../tutorial/tutorialSteps";

const TutorialContext = createContext({
  isTutorialActive: false,
  currentStepIndex: 0,
  warningNotice: null,
  completionCount: 0,
  mhPlacedCount: 0,
  tutorialRuntime: {
    isShopOpen: false,
    selectedBuildingId: null,
  },
  startTutorial: () => {},
  advanceStep: () => {},
  exitTutorial: () => {},
  fireEvent: () => {},
  clearWarningNotice: () => {},
  showWarningNotice: () => {},
  setTutorialRuntime: () => {},
  jumpToSection: () => {},
});

const LS_KEY = "qi_tutorial";

const persistProgress = (payload) => {
  try {
    localStorage.setItem(LS_KEY, JSON.stringify(payload));
  } catch {
    // no-op
  }
};

const actionMatches = (expected, actual) => {
  if (expected === actual) return true;
  if (expected === "build" && actual === "buildAdmin") return true;
  if (expected === "harvest" && actual === "harvestAdmin") return true;
  if (expected === "harvestAll" && actual === "harvestAllAdmin") return true;
  if (expected === "finishProductions" && actual === "finishProductionsAdmin") return true;
  return false;
};

export function TutorialProvider({ children }) {
  const [isTutorialActive, setIsTutorialActive] = useState(false);
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [warningNotice, setWarningNotice] = useState(null);
  const [completionCount, setCompletionCount] = useState(0);
  const [mhPlacedCount, setMhPlacedCount] = useState(0);
  const [harvestManualCount, setHarvestManualCount] = useState(0);
  const [awaitHarvestPopupClose, setAwaitHarvestPopupClose] = useState(false);
  const [tutorialRuntime, setTutorialRuntime] = useState({
    isShopOpen: false,
    selectedBuildingId: null,
  });

  const clearWarningNotice = useCallback(() => {
    setWarningNotice(null);
  }, []);

  const showWarningNotice = useCallback((reason = "unexpected-popup") => {
    setWarningNotice({
      id: Date.now(),
      reason,
    });
  }, []);

  const initializeStepState = useCallback((stepIndex) => {
    const step = TUTORIAL_STEPS[stepIndex];
    if (!step) return;
    if (step.id === "board-place-mh-sequence") {
      setMhPlacedCount(0);
    }
    if (step.id === "board-harvest") {
      setHarvestManualCount(0);
      setAwaitHarvestPopupClose(false);
    }
  }, []);

  const finishTutorial = useCallback((lastStep) => {
    setIsTutorialActive(false);
    setWarningNotice(null);
    setCompletionCount((prev) => prev + 1);
    persistProgress({
      completed: true,
      dismissed: true,
      lastStep,
    });
  }, []);

  const jumpToStep = useCallback(
    (stepIndex) => {
      const next = Math.max(0, Math.min(stepIndex, TUTORIAL_STEPS.length - 1));
      initializeStepState(next);
      setWarningNotice(null);
      setCurrentStepIndex(next);
      persistProgress({
        completed: false,
        dismissed: false,
        lastStep: next,
      });
    },
    [initializeStepState],
  );

  const advanceFromCurrent = useCallback(() => {
    const next = currentStepIndex + 1;
    if (next >= TUTORIAL_STEPS.length) {
      finishTutorial(currentStepIndex);
      return;
    }
    jumpToStep(next);
  }, [currentStepIndex, finishTutorial, jumpToStep]);

  const jumpToSection = useCallback(
    (sectionKey) => {
      const idx = TUTORIAL_STEPS.findIndex((item) => item.section === sectionKey);
      if (idx < 0) return;
      jumpToStep(idx);
    },
    [jumpToStep],
  );

  const startTutorial = useCallback(
    (fromStep = 0) => {
      const safeStep = Math.max(0, Math.min(fromStep, TUTORIAL_STEPS.length - 1));
      setIsTutorialActive(true);
      setMhPlacedCount(0);
      setHarvestManualCount(0);
      setAwaitHarvestPopupClose(false);
      setTutorialRuntime({
        isShopOpen: false,
        selectedBuildingId: null,
      });
      jumpToStep(safeStep);
    },
    [jumpToStep],
  );

  const advanceStep = useCallback(() => {
    advanceFromCurrent();
  }, [advanceFromCurrent]);

  const exitTutorial = useCallback(() => {
    setIsTutorialActive(false);
    setWarningNotice(null);
    persistProgress({
      completed: false,
      dismissed: true,
      lastStep: currentStepIndex,
    });
  }, [currentStepIndex]);

  const fireEvent = useCallback(
    (eventName, payload = {}) => {
      if (!isTutorialActive) return;
      const step = TUTORIAL_STEPS[currentStepIndex];
      if (!step) return;

      if (step.id === "board-place-mh-sequence") {
        if (eventName === "building-selected" && payload?.defId && payload.defId !== "mehrgeschossiges_haus") {
          showWarningNotice("wrong-building");
          return;
        }

        if (!actionMatches("build", eventName)) return;
        const expected = MH_TARGET_SLOTS[mhPlacedCount];
        if (!expected) return;
        const isMh = payload?.shortId === "H1" || payload?.defId === "mehrgeschossiges_haus";
        const isExactSlot = payload?.x === expected.x && payload?.y === expected.y;
        if (!isMh || !isExactSlot) {
          showWarningNotice("wrong-placement");
          return;
        }
        const nextCount = mhPlacedCount + 1;
        if (nextCount >= MH_TARGET_SLOTS.length) {
          setMhPlacedCount(nextCount);
          advanceFromCurrent();
          return;
        }
        setMhPlacedCount(nextCount);
        return;
      }

      if (step.id === "board-harvest") {
        if (actionMatches("harvestAll", eventName)) {
          setAwaitHarvestPopupClose(true);
          return;
        }
        if (eventName === "harvest-popup-closed" && awaitHarvestPopupClose) {
          advanceFromCurrent();
          return;
        }
        if (actionMatches("harvest", eventName)) {
          const nextCount = harvestManualCount + 1;
          if (nextCount >= MH_TARGET_SLOTS.length) {
            setHarvestManualCount(nextCount);
            advanceFromCurrent();
            return;
          }
          setHarvestManualCount(nextCount);
        }
        return;
      }

      if (step.id === "save-load-load-example") {
        if (eventName !== "loadExampleSave") return;
        if (payload?.name !== TUTORIAL_EXAMPLE_SAVE_NAME) {
          showWarningNotice("wrong-savefile");
          return;
        }
        advanceFromCurrent();
        return;
      }

      if (step.advanceOn !== "action") return;
      if (!actionMatches(step.actionType, eventName)) return;
      advanceFromCurrent();
    },
    [
      advanceFromCurrent,
      awaitHarvestPopupClose,
      currentStepIndex,
      harvestManualCount,
      isTutorialActive,
      mhPlacedCount,
      showWarningNotice,
    ],
  );

  const value = useMemo(
    () => ({
      isTutorialActive,
      currentStepIndex,
      warningNotice,
      completionCount,
      mhPlacedCount,
      tutorialRuntime,
      startTutorial,
      advanceStep,
      exitTutorial,
      fireEvent,
      clearWarningNotice,
      showWarningNotice,
      setTutorialRuntime,
      jumpToSection,
    }),
    [
      isTutorialActive,
      currentStepIndex,
      warningNotice,
      completionCount,
      mhPlacedCount,
      tutorialRuntime,
      startTutorial,
      advanceStep,
      exitTutorial,
      fireEvent,
      clearWarningNotice,
      showWarningNotice,
      jumpToSection,
    ],
  );

  return <TutorialContext.Provider value={value}>{children}</TutorialContext.Provider>;
}

export function useTutorial() {
  return useContext(TutorialContext);
}

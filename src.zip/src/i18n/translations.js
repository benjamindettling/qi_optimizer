﻿export const T = {
  // === LANGUAGE TOGGLE ===
  langToggleTitle_DE: { DE: "Auf Englisch wechseln", EN: "Switch to German" },

  // === STARTING PAGE ===
  startTitle: {
    DE: "Quantum Incursion Optimizer",
    EN: "Quantum Incursion Optimizer",
  },
  startSubtitle: {
    DE: "Stadtplanung leicht gemacht",
    EN: "City planning made easy",
  },
  startOpenSaves: { DE: "Spielstand laden", EN: "Load Save" },
  startOpenAccount: { DE: "Account", EN: "Account" },
  startOpenSimulator: { DE: "Simulator starten", EN: "Start Simulator" },
  startConfigTitle: { DE: "Spieler-Konfiguration", EN: "Player Configuration" },
  startConfigSave: { DE: "Speichern", EN: "Save" },
  startConfigCancel: { DE: "Abbrechen", EN: "Cancel" },
  startConfigReset: { DE: "Zurücksetzen", EN: "Reset" },

  // --- Tutorial ---
  tutorialHeading: {
    DE: "Tutorial und komplette Oberflächen-Erklärung",
    EN: "Tutorial and Complete UI Explanation",
  },
  tutorialStart: { DE: "Tutorial starten", EN: "Start Tutorial" },
  tutorialExit: { DE: "Tutorial beenden", EN: "Exit Tutorial" },
  tutorialNext: { DE: "Weiter", EN: "Next" },
  tutorialFinish: { DE: "Tutorial beenden", EN: "Finish Tutorial" },
  tutorialWaiting: { DE: "Warte auf Aktion…", EN: "Waiting for action…" },
  tutorialFirstVisit: {
    DE: "Neu hier? Starte das Tutorial!",
    EN: "New here? Try the tutorial!",
  },
  tutorialFirstVisitBtn: { DE: "Starten", EN: "Start" },
  tutorialStepCounter: { DE: "Schritt {current} / {total}", EN: "Step {current} / {total}" },
  tutorialUnexpectedTitle: {
    DE: "Das war noch nicht der nächste Schritt",
    EN: "That is not the next tutorial step yet",
  },
  tutorialUnexpectedBody: {
    DE: "Bitte folge der aktuellen Anleitung im Tutorial-Popup.",
    EN: "Please follow the current instruction in the tutorial popup.",
  },
  tutorialDismiss: { DE: "Verstanden", EN: "Got it" },
  tutorialSectionProgress: {
    DE: "Abschnitte {current} / {total}",
    EN: "Sections {current} / {total}",
  },
  tutorialMhProgress: {
    DE: "Mehrgeschossige Häuser: {current} / {total}",
    EN: "Multi-Storey Houses: {current} / {total}",
  },
  tutorialSection_basicOverview: { DE: "Basisüberblick", EN: "Basic Overview" },
  tutorialSection_board: { DE: "Board", EN: "Board" },
  tutorialSection_tree: { DE: "Baum", EN: "Tree" },
  tutorialSection_saveLoad: { DE: "Speichern/Laden", EN: "Save/Load" },
  tutorialSection_help: { DE: "Hilfe", EN: "Help" },

  tutorialStepOverviewAllTitle: {
    DE: "Basisüberblick",
    EN: "Basic Overview",
  },
  tutorialStepOverviewAllBody: {
    DE: "Lass uns zuerst einen Überblick verschaffen (btw du kannst das Tutorial Fenster jederzeit verschieben wenn es im Weg ist).",
    EN: "Here you see the main areas: board, board toolbar, tree, tree toolbar, notes, and the three top bar areas. Click Next.",
  },
  tutorialStepOverviewBoardTitle: { DE: "Board", EN: "Board" },
  tutorialStepOverviewBoardBody: {
    DE: "Das Board ist dein Spielfeld. Hier platzierst, verschiebst und verwaltest du Gebäude.",
    EN: "The board is your playfield. You place, move, and manage buildings here.",
  },
  tutorialStepOverviewBoardToolbarTitle: {
    DE: "Board-Toolbar",
    EN: "Board Toolbar",
  },
  tutorialStepOverviewBoardToolbarBody: {
    DE: "Diese Toolbar steuert Shop, Bewegen, Verkaufen, Boost sowie Produktions- und Ernteaktionen.",
    EN: "This toolbar controls shop, move, sell, boost, plus production and harvest actions.",
  },
  tutorialStepOverviewTreeTitle: { DE: "Verlaufsbaum", EN: "History Tree" },
  tutorialStepOverviewTreeBody: {
    DE: "Der Baum zeigt deine Aktionen als Knoten und Verzweigungen für alternative Pfade. Klingt kompliziert, ist es aber nicht. Aber dazu später mehr.",
    EN: "The tree shows your actions as nodes and branches for alternative paths.",
  },
  tutorialStepOverviewTreeToolbarTitle: {
    DE: "Baum-Toolbar",
    EN: "Tree Toolbar",
  },
  tutorialStepOverviewTreeToolbarBody: {
    DE: "Hier kontrollierst du was der Baum anzeigt, und kannst ihn editieren. Aber wie gesagt, dazu später mehr.",
    EN: "Here you control tree view, main branch selection, and delete functions.",
  },
  tutorialStepOverviewTopbarStatsTitle: {
    DE: "TopBar: Statistiken",
    EN: "Top Bar: Stats",
  },
  tutorialStepOverviewTopbarStatsBody: {
    DE: "Hier siehst du Ressourcen, Truppen, Boosts und Happiness. In der Happiness-Spalte erkennst du je Stufe, was fehlt oder übrig ist.",
    EN: "Here you see resources, units, boosts, and happiness. The happiness column shows per tier what is missing or extra.",
  },
  tutorialStepOverviewTopbarStepsTitle: {
    DE: "TopBar: Schritt",
    EN: "Top Bar: Step",
  },
  tutorialStepOverviewTopbarStepsBody: {
    DE: "Dieser Bereich zeigt den aktuellen Simulationsschritt und bietet Navigation zwischen Aktionen und Checkpoints.",
    EN: "This area shows the current simulation step and navigation between actions and checkpoints.",
  },
  tutorialStepOverviewTopbarButtonsTitle: {
    DE: "TopBar: Buttons",
    EN: "Top Bar: Buttons",
  },
  tutorialStepOverviewTopbarButtonsBody: {
    DE: "Hier findest du Speichern/Laden, Profil, Hilfe, Sprache und den Tutorial-Start.",
    EN: "Here you find save/load, profile, help, language, and tutorial start.",
  },
  tutorialStepOverviewNotesTitle: { DE: "Log und weiteres", EN: "Notes and Log" },
  tutorialStepOverviewNotesBody: {
    DE: "Das Log zeigt eine Übersicht der getätigten Aktionen an. Aktuell ist es noch leer, das ändern wir jetzt.",
    EN: "The log shows actions around the selected state. The area also contains other useful features.",
  },

  tutorialStepBoardPlaceMhTitle: {
    DE: "6 Mehrgeschossige Häuser platzieren",
    EN: "Place 6 Multi-Storey Houses",
  },
  tutorialStepBoardPlaceMhBody: {
    DE: "Platziere 6 Mehrgeschossige Häuser unten im Startgebiet von links nach rechts. Das Tutorial zeigt dir jeweils den nächsten Schritt.",
    EN: "Place 6 Multi-Storey Houses in the lower part of the start area from left to right. The tutorial highlights each next target.",
  },
  tutorialStepBoardFinishTitle: { DE: "Produktionen beenden", EN: "Finish Productions" },
  tutorialStepBoardFinishBody: {
    DE: "Dieser Button springt in der Zeit vor und markiert alle Produktionen als fertig.",
    EN: "This button jumps forward in time and marks all productions as finished.",
  },
  tutorialStepBoardHarvestTitle: { DE: "Alles einsammeln", EN: "Collect Everything" },
  tutorialStepBoardHarvestBody: {
    DE: "Du kannst Gebäude einzeln ernten oder alles auf einmal. Dieser Schritt endet nach kompletter Ernte.",
    EN: "You can harvest buildings individually or all at once. This step finishes after everything is collected.",
  },
  tutorialStepBoardToolsTitle: { DE: "Move, Sell, Boost", EN: "Move, Sell, Boost" },
  tutorialStepBoardToolsBody: {
    DE: "Move verschiebt Gebäude, Sell verkauft sie, Boost beschleunigt einzelne Gebäude.",
    EN: "Move repositions buildings, Sell removes them, and Boost accelerates single buildings.",
  },

  tutorialStepTreeIntroTitle: { DE: "Baum verstehen", EN: "Understand the Tree" },
  tutorialStepTreeIntroBody: {
    DE: "Jeder Knoten ist eine Aktion. Grün steht für Bauen, große Dreiecke zeigen Zeitsprünge.",
    EN: "Each node is one action. Green indicates building, and big triangles are time jumps.",
  },
  tutorialStepTreeGoStartTitle: {
    DE: "Zum Start navigieren",
    EN: "Navigate to Start",
  },
  tutorialStepTreeGoStartBody: {
    DE: "Navigiere jetzt über den Baum bis ganz zurück zum Root-Knoten.",
    EN: "Now navigate through the tree all the way back to the root node.",
  },
  tutorialStepTreeCopyTitle: { DE: "Branch erstellen", EN: "Create a Branch" },
  tutorialStepTreeCopyBody: {
    DE: "Ziehe den MH2-Knoten auf den Root-Knoten. Der Pfeil zeigt die gewünschte Bewegung.",
    EN: "Drag the MH2 node onto the root node. The arrow shows the target motion.",
  },
  tutorialStepTreeDeleteTitle: {
    DE: "Node löschen (ohne Folgeknoten)",
    EN: "Delete Node (keep following nodes)",
  },
  tutorialStepTreeDeleteBody: {
    DE: "Lösche den ersten MH-Knoten des neuen Branches und deaktiviere dabei 'alle nachfolgenden Nodes'.",
    EN: "Delete the first MH node of the new branch and disable the 'delete following nodes' option.",
  },
  tutorialStepTreeMainBranchTitle: {
    DE: "Zum Hauptbranch machen",
    EN: "Set as Main Branch",
  },
  tutorialStepTreeMainBranchBody: {
    DE: "Markiere den aktuellen Branch jetzt als Hauptbranch.",
    EN: "Set the current branch as the main branch now.",
  },
  tutorialStepTreeFocusBtnTitle: {
    DE: "Focus-Button",
    EN: "Focus Button",
  },
  tutorialStepTreeFocusBtnBody: {
    DE: "Klicke den Focus-Button einmal, um die Funktion kennenzulernen.",
    EN: "Click the focus button once to see what it does.",
  },
  tutorialStepTreeCollapseBtnTitle: {
    DE: "Collapse-Button",
    EN: "Collapse Button",
  },
  tutorialStepTreeCollapseBtnBody: {
    DE: "Klicke jetzt den horizontalen Collapse-Button einmal.",
    EN: "Now click the horizontal collapse button once.",
  },

  tutorialStepSaveLoadSaveTitle: { DE: "Spielstand speichern", EN: "Save Game" },
  tutorialStepSaveLoadSaveBody: {
    DE: "Speichere den aktuellen Stand (zum Beispiel als 'tutorial').",
    EN: "Save the current state (for example as 'tutorial').",
  },
  tutorialStepSaveLoadOpenMenuTitle: {
    DE: "Load-Menü öffnen",
    EN: "Open Load Menu",
  },
  tutorialStepSaveLoadOpenMenuBody: {
    DE: "Öffne jetzt das Load-Menü. Das Beispiel-Savefile ist dort bereits vorbereitet.",
    EN: "Open the load menu now. The example savefile is already prepared there.",
  },
  tutorialStepSaveLoadBtnLoadTitle: { DE: "Load-Button", EN: "Load Button" },
  tutorialStepSaveLoadBtnLoadBody: {
    DE: "Mit diesem Button lädst du den gewählten Spielstand.",
    EN: "This button loads the selected savefile.",
  },
  tutorialStepSaveLoadBtnConfigTitle: {
    DE: "Savefile-Config",
    EN: "Savefile Config",
  },
  tutorialStepSaveLoadBtnConfigBody: {
    DE: "Hier kannst du setup-spezifische Savefile-Konfigurationen bearbeiten.",
    EN: "Here you can edit setup-specific savefile configurations.",
  },
  tutorialStepSaveLoadBtnRenameTitle: { DE: "Umbenennen", EN: "Rename" },
  tutorialStepSaveLoadBtnRenameBody: {
    DE: "Dieser Button ändert den Namen eines Savefiles.",
    EN: "This button changes the name of a savefile.",
  },
  tutorialStepSaveLoadBtnExportTitle: { DE: "Export", EN: "Export" },
  tutorialStepSaveLoadBtnExportBody: {
    DE: "Exportiert das Savefile als JSON-Datei.",
    EN: "Exports the savefile as a JSON file.",
  },
  tutorialStepSaveLoadBtnDeleteTitle: { DE: "Löschen", EN: "Delete" },
  tutorialStepSaveLoadBtnDeleteBody: {
    DE: "Löscht das ausgewählte Savefile dauerhaft.",
    EN: "Permanently deletes the selected savefile.",
  },
  tutorialStepSaveLoadLoadExampleTitle: {
    DE: "Beispiel laden",
    EN: "Load Example",
  },
  tutorialStepSaveLoadLoadExampleBody: {
    DE: "Lade jetzt das Beispiel-Savefile und schließe danach das Load-Menü.",
    EN: "Load the example savefile now and then close the load menu.",
  },
  tutorialStepSaveLoadCloseMenuTitle: {
    DE: "Load-Menü schließen",
    EN: "Close Load Menu",
  },
  tutorialStepSaveLoadCloseMenuBody: {
    DE: "Schließe das Load-Menü, um zum Simulator zurückzukehren.",
    EN: "Close the load menu to return to the simulator.",
  },
  tutorialStepSaveLoadStepJumpTitle: {
    DE: "Schritte springen",
    EN: "Jump Through Steps",
  },
  tutorialStepSaveLoadStepJumpBody: {
    DE: "Über die Schrittleiste kannst du einzelne Aktionen oder ganze Zeitabschnitte anspringen.",
    EN: "The step panel lets you jump through single actions or whole time segments.",
  },

  tutorialStepHelpTitle: { DE: "Hilfe", EN: "Help" },
  tutorialStepHelpBody: {
    DE: "Weitere Informationen findest du über den Hilfe-Button.",
    EN: "You can find more information via the help button.",
  },
  tutorialStepCompleteTitle: {
    DE: "Tutorial abgeschlossen",
    EN: "Tutorial Complete",
  },
  tutorialStepCompleteBody: {
    DE: "Fertig. Der Simulator wird jetzt auf einen frischen Startzustand zurückgesetzt.",
    EN: "Done. The simulator will now reset to a fresh start state.",
  },

  // === TOPBAR – STEP TRACKER ===
  stepLabel: { DE: "Schritt", EN: "Step" },
  stepMorgen: { DE: "Morgen", EN: "Morning" },
  stepAbend: { DE: "Abend", EN: "Evening" },
  stepDayMon: { DE: "Mo", EN: "Mon" },
  stepDayTue: { DE: "Di", EN: "Tue" },
  stepDayWed: { DE: "Mi", EN: "Wed" },
  stepDayThu: { DE: "Do", EN: "Thu" },
  stepDayFri: { DE: "Fr", EN: "Fri" },
  stepDaySat: { DE: "Sa", EN: "Sat" },
  stepDaySun: { DE: "So", EN: "Sun" },
  stepJumpFirst: {
    DE: "Zum ersten Schritt springen",
    EN: "Jump to first step",
  },
  stepBack: { DE: "Einen Schritt zurück", EN: "One step back" },
  stepForward: { DE: "Einen Schritt vorwärts", EN: "One step forward" },
  stepJumpLast: { DE: "Zum letzten Schritt springen", EN: "Jump to last step" },

  // === TOPBAR – VIEW CONTROLS BUTTONS ===
  btnAdminTitle: {
    DE: "Admin-Modus: freies Bauen, Region-Tools, Ressourcenbearbeitung",
    EN: "Admin mode: free building, region tools, resource editing",
  },
  btnAdminLabel: { DE: "Admin", EN: "Admin" },
  btnHelpTitle: { DE: "Hilfe", EN: "Help" },
  btnHelpLabel: { DE: "Hilfe", EN: "Help" },
  btnProfileTitle: { DE: "Profil", EN: "Profile" },
  btnProfileLabel: { DE: "Profil", EN: "Profile" },
  btnLangTitle_DE: { DE: "Auf Englisch wechseln", EN: "Switch to German" },

  // === TOPBAR – SAVE CONTROLS ===
  btnSaveTitle: { DE: "Speichern", EN: "Save" },
  btnLoadTitle: { DE: "Laden", EN: "Load" },
  btnQuickMenuTitle: { DE: "Schnellmenü", EN: "Quick menu" },
  quickMenuHeader: { DE: "Schnellzugriff", EN: "Quick Access" },
  quickMenuExport: { DE: "Export", EN: "Export" },
  quickMenuImport: { DE: "Import", EN: "Import" },
  syncConfigTitle: {
    DE: "Savefile-Config mit deiner Config synchronisieren",
    EN: "Sync savefile config with your config",
  },
  confirmDeleteSave: { DE: "wirklich löschen?", EN: "really delete?" },
  promptSaveName: { DE: "Save name?", EN: "Save name?" },

  // === TOPBAR – RESOURCE LABELS ===
  resourceCoins: { DE: "Münzen", EN: "Coins" },
  resourceSupplies: { DE: "Vorräte", EN: "Supplies" },
  resourceChronos: { DE: "Chronos", EN: "Chronos" },
  resourceShards: { DE: "Scherben", EN: "Shards" },
  resourceQA: { DE: "QA", EN: "QA" },
  attackBoostLabel: { DE: "Angriff Boost", EN: "Attack Boost" },
  defenseBoostLabel: { DE: "Verteidigung Boost", EN: "Defense Boost" },

  // === ACTION TOOLBAR – BOARD TOOLBAR BUTTONS ===
  toolMoveTitle: {
    DE: "Bewege oder tausche Gebäude nach Belieben",
    EN: "Move or swap buildings freely",
  },
  toolSellTitle: {
    DE: "Verkauf Gebäude. Erhalte 1/4 des gezahlten Werts zurück",
    EN: "Sell buildings. Receive 1/4 of the paid value back",
  },
  toolBoostTitle: {
    DE: "Boost einzelne Gebäude: entsperre oder beende Produktionen",
    EN: "Boost individual buildings: unlock or finish productions",
  },
  toolHarvestPartialTitle: {
    DE: "Sammelt nur fertige Produktionen ein",
    EN: "Collects only finished productions",
  },
  toolHarvestFullTitle: {
    DE: "Volle Ernte: erntet die gesamte Stadt",
    EN: "Full harvest: harvest the entire city",
  },
  toolFinishProductionsTitle: {
    DE: "Beendet alle Produktionen. Danach kannst du ernten",
    EN: "Finishes all productions. You can then harvest",
  },
  toolSnapshotBackTitle: {
    DE: "Vorherigen Snapshot laden",
    EN: "Load previous snapshot",
  },
  toolSnapshotForwardTitle: {
    DE: "Nächsten Snapshot laden",
    EN: "Load next snapshot",
  },
  toolSaveBrowserTitle: {
    DE: "Speicher aktuellen Stand (inkl. Undo/Redo) in deinem Browser.",
    EN: "Save current state (incl. Undo/Redo) in your browser.",
  },
  toolExportPdfTitle: {
    DE: "Aktuelle Datei als PDF exportieren",
    EN: "Export current file as PDF",
  },
  toolPastEditTitle: {
    DE: "Bearbeitung im Vergangenheitszustand aktivieren",
    EN: "Enable editing in past state",
  },
  toolRefundTitle: {
    DE: "DEBUG: Erhalte den VOLLEN Wert des Gebäudes zurück",
    EN: "DEBUG: Receive the FULL building value back",
  },

  // === ACTION TOOLBAR – TREE BUTTONS ===
  treePrevCheckpoint: {
    DE: "Vorheriger Checkpoint (Shift+←)",
    EN: "Previous checkpoint (Shift+←)",
  },
  treeStepBack: { DE: "Schritt zurück (←)", EN: "Step back (←)" },
  treeStepForward: { DE: "Schritt vor (→)", EN: "Step forward (→)" },
  treeNextCheckpoint: {
    DE: "Nächster Checkpoint (Shift+→)",
    EN: "Next checkpoint (Shift+→)",
  },

  // === NOTES SECTION ===
  notesLabel: { DE: "Notizen", EN: "Notes" },
  notesPlaceholder: { DE: "Füge Notizen hinzu", EN: "Add notes" },

  // === BOARD – EXPANSION COST NOTICE ===
  expansionCostLabel: {
    DE: "Nächste Erweiterung kostet",
    EN: "Next expansion costs",
  },
  goodsAlt: { DE: "Güter", EN: "Goods" },
  shardsAlt: { DE: "Scherben", EN: "Shards" },

  // === LOAD SAVES MODAL ===
  loadSavesTitle: { DE: "Spielstand laden", EN: "Load Save" },
  loadSavesClose: { DE: "Schliessen", EN: "Close" },
  loadSavesDeleteTitle: { DE: "Spielstand löschen", EN: "Delete Save" },
  loadSavesUnsavedTitle: {
    DE: "Ungespeicherte Änderungen",
    EN: "Unsaved Changes",
  },
  loadSavesBtnConfirm: { DE: "Bestätigen", EN: "Confirm" },
  loadSavesBtnCancel: { DE: "Abbrechen", EN: "Cancel" },
  loadSavesBtnSaveConfig: { DE: "Savefile-Config", EN: "Savefile Config" },
  loadSavesBtnRename: { DE: "Umbenennen", EN: "Rename" },
  loadSavesBtnExport: { DE: "Exportieren", EN: "Export" },
  loadSavesBtnDelete: { DE: "Löschen", EN: "Delete" },

  // === ACCOUNT / PROFILE MODAL ===
  accountTabAccount: { DE: "Account", EN: "Account" },
  accountTabConfig: { DE: "Config", EN: "Config" },
  accountTabPreferences: { DE: "Präferenzen", EN: "Preferences" },
  accountTabPremium: { DE: "Premium", EN: "Premium" },
  accountTabContact: { DE: "Kontakt", EN: "Contact" },
  accountTabImprint: { DE: "Impressum", EN: "Imprint" },
  accountTabPrivacy: { DE: "Datenschutz", EN: "Privacy" },
  accountPremiumTitle: {
    DE: "Premium demnächst erhältlich",
    EN: "Premium coming soon",
  },
  accountPrivacyDataTitle: { DE: "Verarbeitete Daten", EN: "Processed Data" },
  accountPrivacyPurposeTitle: { DE: "Zwecke", EN: "Purposes" },
  accountPrivacyAdsTitle: {
    DE: "Google AdSense (geplant)",
    EN: "Google AdSense (planned)",
  },
  accountPrivacyContactTitle: {
    DE: "Kontakt für Datenschutzanfragen",
    EN: "Contact for privacy requests",
  },
  accountConfigRedAttack: {
    DE: "Roter Angriff % Bonus",
    EN: "Red Attack % Bonus",
  },
  accountConfigRedDefense: {
    DE: "Rote Verteidigung % Bonus",
    EN: "Red Defense % Bonus",
  },
  accountConfigBlueAttack: {
    DE: "Blauer Angriff % Bonus",
    EN: "Blue Attack % Bonus",
  },
  accountConfigBlueDefense: {
    DE: "Blaue Verteidigung % Bonus",
    EN: "Blue Defense % Bonus",
  },

  // === EXTRA KEYS USED IN CURRENT UI ===
  langToggleTitle_EN: { DE: "Auf Deutsch wechseln", EN: "Switch to English" },
  langCodeDE: { DE: "DE", EN: "DE" },
  langCodeEN: { DE: "EN", EN: "EN" },

  startHeroText: {
    DE: "Plane und optimiere dein Quantum Incursion Stadtlayout. Platziere Gebäude, berechne Produktionsketten und verwalte mehrere Spielstände - alles direkt im Browser.",
    EN: "Plan and optimize your Quantum Incursion city layout. Place buildings, calculate production chains, and manage multiple saves - all directly in your browser.",
  },
  startPrimaryAction: { DE: "Simulator starten", EN: "Start Simulator" },
  startSecondarySaves: { DE: "Spielstände verwalten", EN: "Manage Saves" },
  startSecondarySettings: { DE: "Einstellungen", EN: "Settings" },
  startFooterLegalAria: { DE: "Rechtliche Links", EN: "Legal links" },
  startFooterTutorialAria: { DE: "Tutorial", EN: "Tutorial" },
  startConfigSubtitle: {
    DE: "Trage deine aktuellen Boni und Boosts ein, damit der Simulator korrekte Werte berechnet. Du kannst diese später jederzeit in den Einstellungen anpassen.",
    EN: "Enter your current bonuses and boosts so the simulator can calculate correctly. You can adjust them later in settings.",
  },
  startConfigConfirmSaveAndContinue: {
    DE: "Speichern und Weiter",
    EN: "Save and Continue",
  },
  startConfigConfirmContinue: { DE: "Weiter", EN: "Continue" },
  startConfigConfirmSkip: { DE: "Überspringen", EN: "Skip" },

  configLabelExtraCoins: { DE: "Münzen Extra", EN: "Extra Coins" },
  configLabelExtraSupplies: { DE: "Vorräte Extra", EN: "Extra Supplies" },
  configLabelExtraGoods: { DE: "Güter Extra", EN: "Extra Goods" },
  configLabelExtraTroops: { DE: "Truppen Extra", EN: "Extra Troops" },
  configLabelShardsStart: { DE: "Scherben Start", EN: "Starting Shards" },
  configLabelCoinBoost: { DE: "Münzen % Boost", EN: "Coins % Boost" },
  configLabelSupplyBoost: { DE: "Vorräte % Boost", EN: "Supplies % Boost" },
  configLabelFightColor: { DE: "Farbe zum Kämpfen", EN: "Fight Color" },
  configLabelQaPerHour: { DE: "QA pro Stunde Extra", EN: "Extra QA per Hour" },
  colorRed: { DE: "Rot", EN: "Red" },
  colorBlue: { DE: "Blau", EN: "Blue" },

  loadSavesEmpty: { DE: "Keine Spielstände gefunden", EN: "No saves found" },
  loadSavesImportHint: {
    DE: "Klicken oder Datei hierher ziehen zum Importieren",
    EN: "Click or drag a file here to import",
  },
  loadSavesDeletePrompt: {
    DE: "Wirklich \"{name}\" löschen?",
    EN: "Really delete \"{name}\"?",
  },
  loadSavesUnsavedPrompt: {
    DE: "Es gibt ungespeicherte Änderungen. Wirklich zu \"{name}\" wechseln?",
    EN: "There are unsaved changes. Really switch to \"{name}\"?",
  },
  loadSavesSwitch: { DE: "Wechseln", EN: "Switch" },
  loadSavesImportError: {
    DE: "Datei konnte nicht importiert werden",
    EN: "Could not import file",
  },

  accountSaveFailed: { DE: "Speichern fehlgeschlagen", EN: "Saving failed" },

  accountConfigBoardSize: { DE: "Board Größe (%)", EN: "Board Size (%)" },
  accountConfigBoardOrientation: {
    DE: "Board Orientierung",
    EN: "Board Orientation",
  },
  accountConfigToolbarPosition: {
    DE: "Board Toolbar Position",
    EN: "Board Toolbar Position",
  },
  accountConfigToolbarLeft: { DE: "Links", EN: "Left" },
  accountConfigToolbarTop: { DE: "Oben", EN: "Top" },
  accountConfigSkipButtons: { DE: "Skip Buttons springen bis", EN: "Skip Buttons jump to" },
  accountConfigSkipEnd: { DE: "Ende des Checkpoints", EN: "End of checkpoint" },
  accountConfigSkipStart: { DE: "Anfang des Checkpoints", EN: "Start of checkpoint" },
  accountConfigColorTheme: { DE: "Farbtheme", EN: "Color Theme" },
  accountConfigThemeLight: { DE: "Hell", EN: "Light" },
  accountConfigThemeDark: { DE: "Dunkel", EN: "Dark" },
  accountConfigPlacementMode: { DE: "Gebäude setzen", EN: "Building placement" },
  accountConfigPlacementMulti: {
    DE: "Mehrere hintereinander",
    EN: "Place multiple in a row",
  },
  accountConfigPlacementReopen: { DE: "Shop neu öffnen", EN: "Re-open shop" },
  accountConfigPlacementSingle: { DE: "Modus beenden", EN: "Exit mode" },

  menuSyncLabel: { DE: "Sync", EN: "Sync" },
  menuSyncTitle: {
    DE: "Savefile-Config mit deiner Config synchronisieren",
    EN: "Sync savefile config with your config",
  },
  menuSaveUnsavedTitle: {
    DE: "Speichern (ungespeicherte Änderungen)",
    EN: "Save (unsaved changes)",
  },

  legalBack: { DE: "Zurück", EN: "Back" },
  legalBackAria: { DE: "Zur vorherigen Seite", EN: "Back to previous page" },

  legalContactTitle: { DE: "Kontakt", EN: "Contact" },
  legalContactIntro: {
    DE: "Wenn du Fragen hast oder Inhalte melden möchtest, kannst du mich direkt kontaktieren.",
    EN: "If you have questions or want to report content, you can contact me directly.",
  },
  legalContactNameLabel: { DE: "Name", EN: "Name" },
  legalContactEmailLabel: { DE: "E-Mail", EN: "Email" },
  legalContactResponseLabel: { DE: "Antwortzeit", EN: "Response time" },
  legalContactResponseValue: { DE: "2-3 Werktage", EN: "2-3 business days" },
  legalContactPrivateNote: {
    DE: "Hinweis: Dieses Projekt wird privat und nicht im Namen einer Firma betrieben.",
    EN: "Note: This project is run privately and not on behalf of a company.",
  },

  legalImprintTitle: { DE: "Impressum", EN: "Imprint" },
  legalImprintIntro: {
    DE: "Angaben gemäß Paragraph 5 TMG für ein privat betriebenes Online-Angebot.",
    EN: "Information pursuant to section 5 TMG for a privately operated online service.",
  },
  legalImprintAddressLabel: { DE: "Adresse", EN: "Address" },
  legalImprintAddressValue: { DE: "Winterthur, Schweiz", EN: "Winterthur, Switzerland" },
  legalImprintContentOwnerLabel: {
    DE: "Verantwortlich für Inhalte",
    EN: "Responsible for content",
  },
  legalImprintNoCompany: {
    DE: "Keine Firma, kein Verein und keine gewerbliche Redaktion.",
    EN: "No company, no association, and no commercial editorial office.",
  },

  legalPrivacyTitle: { DE: "Datenschutz", EN: "Privacy" },
  legalPrivacyIntro: {
    DE: "Diese Seite ist ein privat betriebenes Projekt. Personenbezogene Daten werden nur verarbeitet, wenn es technisch notwendig ist oder du sie aktiv eingibst.",
    EN: "This site is a privately operated project. Personal data is processed only when technically required or when you actively provide it.",
  },
  legalPrivacyDataPoint1: {
    DE: "Technische Zugriffsdaten (z. B. IP, Browser, Zeitstempel)",
    EN: "Technical access data (e.g., IP, browser, timestamp)",
  },
  legalPrivacyDataPoint2: {
    DE: "Optional: Login-Daten bei Nutzung der Account-Funktionen",
    EN: "Optional: login data when using account features",
  },
  legalPrivacyDataPoint3: {
    DE: "Optional: Cookie-Einwilligungen und Komfort-Einstellungen",
    EN: "Optional: cookie consent and convenience settings",
  },
  legalPrivacyPurposePoint1: {
    DE: "Bereitstellung und Sicherheit der Webseite",
    EN: "Provision and security of the website",
  },
  legalPrivacyPurposePoint2: {
    DE: "Speichern von Einstellungen und Spielständen",
    EN: "Saving settings and game saves",
  },
  legalPrivacyPurposePoint3: {
    DE: "Betrieb von Login- und Cloud-Funktionen",
    EN: "Operating login and cloud features",
  },
  legalPrivacyAdsBody: {
    DE: "Bei aktivierter Einbindung kann Google AdSense Cookies und nutzungsbezogene Daten für personalisierte oder nicht-personalisierte Werbung verarbeiten. Die Auslieferung erfolgt nur gemäß deiner Consent-Auswahl.",
    EN: "If enabled, Google AdSense may process cookies and usage-related data for personalized or non-personalized advertising. Delivery happens only according to your consent selection.",
  },
  legalPrivacyPlaceholderNote: {
    DE: "Bitte ersetze alle Platzhalter vor dem Live-Betrieb mit deinen echten Angaben.",
    EN: "Please replace all placeholders with your real information before going live.",
  },

  accountHeaderClose: { DE: "Schliessen", EN: "Close" },
};

import military from "./data/military.json";
export const REGION_SIZE = 4;
export const REGION_COLS = 7;
export const REGION_ROWS = 7;
export const BOARD_WIDTH = REGION_COLS * REGION_SIZE;
export const BOARD_HEIGHT = REGION_ROWS * REGION_SIZE;

// UI: Board scaling slider (main board only).
// - BOARD_SCALE_MIN/MAX define the allowed range
// - BOARD_SCALE_DEFAULT defines the initial value (100%)
export const BOARD_SCALE_MIN = 0.01;
export const BOARD_SCALE_MAX = 5.0;
export const BOARD_SCALE_DEFAULT = 1.0;
export const REGION_GOODS_COSTS = [
  30,
  60,
  90,
  130,
  180,
  240,
  310,
  390,
  480,
  580,
  700,
  Infinity,
];
export const REGION_SHARD_COSTS = [
  100,
  150,
  200,
  250,
  300,
  350,
  400,
  450,
  500,
  550,
  600,
  650,
  700,
  750,
  800,
  Infinity,
];
export const GOODS_TYPES = [
  "Kupfer",
  "Honig",
  "Stein",
  "Seil",
  "Schießpulver",
];
export const UNIT_TYPES = Array.from(
  new Set((military || []).map((m) => m.produces).filter(Boolean))
);

export const REGION_MASK = [
  ["N", "N", "U", "U", "U", "U", "N"],
  ["N", "U", "S", "S", "S", "S", "U"],
  ["N", "U", "S", "S", "S", "S", "U"],
  ["N", "U", "S", "S", "S", "S", "U"],
  ["U", "U", "U", "U", "U", "U", "U"],
  ["U", "U", "U", "U", "U", "U", "N"],
  ["U", "U", "U", "U", "U", "U", "N"],
];

export const initialRegions = () =>
  REGION_MASK.flatMap((row) => row.map((cell) => cell === "S"));

export const initialGoods = () =>
  GOODS_TYPES.reduce((acc, key) => ({ ...acc, [key]: 20 }), {});
export const initialUnits = () =>
  UNIT_TYPES.reduce((acc, key) => ({ ...acc, [key]: 0 }), {});

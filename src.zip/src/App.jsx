import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Board } from "./components/Board";
import { TopBar } from "./components/TopBar";
import { ShopSidebar } from "./components/ShopSidebar";
import { ActionToolbar } from "./components/ActionToolbar";
import {
  computePurchasePlans,
  computeRefund,
  formatGoods,
  happinessTier,
} from "./utils/gameMath";
import "./index.css";

import {
  REGION_SIZE,
  REGION_COLS,
  BOARD_WIDTH,
  BOARD_HEIGHT,
  GOODS_TYPES,
  REGION_MASK,
  initialRegions,
  initialGoods,
} from "./config/boardConfig";

import { categories, categoryColors } from "./config/categories";

import { findInstanceAt, findOverlap, isAreaFree } from "./utils/layoutUtils";
import {
  serializeState,
  canAffordSingleGood,
  canAffordResources,
  hasPopulationForDef,
  computeStats,
} from "./utils/stateUtils";
import { useResources } from "./hooks/useResources";
import { useUndoRedo } from "./hooks/useUndoRedo";
import { useRegionAccess } from "./hooks/useRegionAccess";
import { useSaves } from "./hooks/useSaves";

function App() {
  const nextId = useRef(2);
  const visibleCategories = useMemo(
    () => categories.filter((c) => !c.hidden),
    []
  );

  const library = useMemo(
    () =>
      categories.flatMap((cat) =>
        cat.data.map((item) => ({
          ...item,
          category: cat.key,
          defId: `${cat.key}:${item.id}`,
          width: item.size[0],
          height: item.size[1],
        }))
      ),
    []
  );
  const libraryMap = useMemo(
    () => Object.fromEntries(library.map((entry) => [entry.defId, entry])),
    [library]
  );
  const townhallDef = useMemo(
    () => library.find((d) => d.category === "townhall"),
    [library]
  );

  const initialRegionState = useMemo(() => initialRegions(), []);
  const {
    resources,
    setResources,
    spendResources,
    refundResources,
    adjustGoods,
  } = useResources({
    coins: 450000,
    supplies: 75000,
    chronos: 0,
    shards: 500,
    goods: initialGoods(),
  });
  const initialTownhall = useMemo(() => {
    if (!townhallDef) return [];
    return [
      {
        id: 1,
        defId: townhallDef.defId,
        x: 17,
        y: 4,
        width: townhallDef.width,
        height: townhallDef.height,
      },
    ];
  }, [townhallDef]);

  const [layout, setLayout] = useState(initialTownhall);
  const [unlockedRegions, setUnlockedRegions] = useState(initialRegionState);
  const [goodsUnlocks, setGoodsUnlocks] = useState(0);
  const [shardUnlocks, setShardUnlocks] = useState(0);
  const [selectedCategory, setSelectedCategory] = useState("housing");
  const [selectedBuildingId, setSelectedBuildingId] = useState(null);
  const [hoverCell, setHoverCell] = useState(null);
  const [moveMode, setMoveMode] = useState(false);
  const [sellMode, setSellMode] = useState(false);
  const [refundMode, setRefundMode] = useState(false);
  const [carried, setCarried] = useState(null);
  const [moveSnapshot, setMoveSnapshot] = useState(null);
  const [harvestModal, setHarvestModal] = useState(null);
  const [goodsModal, setGoodsModal] = useState(null);
  const [fastBuyModal, setFastBuyModal] = useState(null);
  const [fastBuyTarget, setFastBuyTarget] = useState(null);
  const [unlockChoice, setUnlockChoice] = useState(null);
  const [unlockGoodSelect, setUnlockGoodSelect] = useState(null);
  const [viewMode, setViewMode] = useState("down");
  const [status, setStatus] = useState("");
  const [readyMap, setReadyMap] = useState(
    initialTownhall.reduce((acc, b) => ({ ...acc, [b.id]: false }), {})
  );
  const {
    saves,
    loadName,
    setLoadName,
    saveSnapshot,
    loadSnapshot,
    deleteSave,
  } = useSaves();

  const handleSaveState = () => {
    const name = prompt("Save name?");
    if (!name) return;
    const snapshot = buildSnapshot();
    saveSnapshot(name, snapshot);
    updateStatus(`Saved state "${name}"`);
  };

  const handleLoadState = (name) => {
    const snap = loadSnapshot(name);
    if (!snap) return;
    applySnapshot(snap);
    setCarried(null);
    setMoveSnapshot(null);
    setMoveMode(false);
    updateStatus(`Loaded state "${name}"`);
  };

  useEffect(() => {
    if (townhallDef && !layout.some((l) => l.defId === townhallDef.defId)) {
      setLayout(initialTownhall);
      nextId.current = Math.max(nextId.current, 2);
      setReadyMap(
        initialTownhall.reduce((acc, b) => ({ ...acc, [b.id]: false }), {})
      );
    }
  }, [townhallDef, layout, initialTownhall]);

  useEffect(() => {
    setReadyMap((prev) => {
      const next = { ...prev };
      layout.forEach((b) => {
        if (next[b.id] === undefined) next[b.id] = false;
      });
      return next;
    });
  }, [layout]);

  const selectedDef = selectedBuildingId
    ? libraryMap[selectedBuildingId]
    : null;

  const updateStatus = (msg) => {
    setStatus(msg);
    setTimeout(() => setStatus(""), 2500);
  };

  const buildSnapshot = useCallback(
    () =>
      serializeState({
        resources,
        layout,
        unlockedRegions,
        goodsUnlocks,
        shardUnlocks,
        nextId: nextId.current,
        readyMap,
        moveMode,
        sellMode,
        refundMode,
        selectedCategory,
      }),
    [
      resources,
      layout,
      unlockedRegions,
      goodsUnlocks,
      shardUnlocks,
      readyMap,
      moveMode,
      sellMode,
      refundMode,
      selectedCategory,
    ]
  );

  const applySnapshot = useCallback(
    (snapshot) => {
      setResources(snapshot.resources);
      setLayout(snapshot.layout);
      setUnlockedRegions(snapshot.unlockedRegions);
      if (snapshot.goodsUnlocks !== undefined)
        setGoodsUnlocks(snapshot.goodsUnlocks);
      if (snapshot.shardUnlocks !== undefined)
        setShardUnlocks(snapshot.shardUnlocks);
      if (snapshot.nextId !== undefined) nextId.current = snapshot.nextId;
      if (snapshot.readyMap) setReadyMap(snapshot.readyMap);
      if (snapshot.moveMode !== undefined) setMoveMode(snapshot.moveMode);
      if (snapshot.sellMode !== undefined) setSellMode(snapshot.sellMode);
      if (snapshot.refundMode !== undefined) setRefundMode(snapshot.refundMode);
      if (snapshot.selectedCategory)
        setSelectedCategory(snapshot.selectedCategory);
      if (
        townhallDef &&
        !snapshot.layout?.some((l) => l.defId === townhallDef.defId)
      ) {
        setLayout((prev) => [
          ...prev,
          {
            id: nextId.current++,
            defId: townhallDef.defId,
            x: 8,
            y: 4,
            width: townhallDef.width,
            height: townhallDef.height,
          },
        ]);
      }
    },
    [setResources, setLayout, setUnlockedRegions, townhallDef]
  );

  const { undoStack, redoStack, pushHistory, handleUndo, handleRedo } =
    useUndoRedo(buildSnapshot, applySnapshot);

  const resetModes = () => {
    setMoveMode(false);
    setSellMode(false);
    setRefundMode(false);
    setSelectedBuildingId(null);
  };

  const undoWithCleanup = () => {
    handleUndo();
    setCarried(null);
    setMoveSnapshot(null);
  };

  const redoWithCleanup = () => {
    handleRedo();
    setCarried(null);
    setMoveSnapshot(null);
  };

  const regionIndexForCell = (x, y) =>
    Math.floor(x / REGION_SIZE) + REGION_COLS * Math.floor(y / REGION_SIZE);

  const isCellUnlocked = (x, y) => {
    const idx = regionIndexForCell(x, y);
    const col = idx % REGION_COLS;
    const row = Math.floor(idx / REGION_COLS);
    if (REGION_MASK[row][col] === "N") return false;
    return unlockedRegions[idx];
  };

  const dropCarried = (x, y) => {
    if (!carried) return;
    if (carried.def.category === "townhall") {
      // allow move
    }
    const def = carried.def;
    const placeX = Math.min(x, BOARD_WIDTH - def.width);
    const placeY = Math.min(y, BOARD_HEIGHT - def.height);
    const overlap = findOverlap(
      layout,
      placeX,
      placeY,
      def.width,
      def.height,
      carried.instance.id
    );
    const areaOk = isAreaFree(
      layout,
      placeX,
      placeY,
      def.width,
      def.height,
      overlap?.id,
      isCellUnlocked
    );
    if (!areaOk) {
      updateStatus("Cannot place here.");
      return;
    }

    if (overlap) {
      setLayout((prev) => {
        const filtered = prev.filter((p) => p.id !== overlap.id);
        const placed = {
          ...carried.instance,
          x: placeX,
          y: placeY,
          width: def.width,
          height: def.height,
        };
        return [...filtered, placed];
      });
      setCarried({
        instance: { ...overlap },
        def: libraryMap[overlap.defId],
      });
      setReadyMap((prev) => ({
        ...prev,
        [carried.instance.id]:
          carried.instance.ready ?? prev[carried.instance.id] ?? false,
        [overlap.id]: prev[overlap.id] ?? false,
      }));
    } else {
      const snapshot = moveSnapshot ?? buildSnapshot();
      setLayout((prev) => [
        ...prev,
        {
          ...carried.instance,
          x: placeX,
          y: placeY,
          width: def.width,
          height: def.height,
        },
      ]);
      setReadyMap((prev) => ({
        ...prev,
        [carried.instance.id]:
          carried.instance.ready ?? prev[carried.instance.id] ?? false,
      }));
      pushHistory(snapshot);
      setCarried(null);
      setMoveSnapshot(null);
      setMoveMode(false);
    }
  };

  const handleCellClick = (x, y) => {
    const target = findInstanceAt(layout, x, y);
    if (carried) {
      dropCarried(x, y);
      return;
    }

    if ((sellMode || refundMode) && target) {
      if (libraryMap[target.defId]?.category === "townhall") {
        updateStatus("Townhall cannot be deleted.");
        return;
      }
      const snapshot = buildSnapshot();
      pushHistory(snapshot);
      const delta =
        refundMode && target.cost
          ? target.cost
          : computeRefund(libraryMap[target.defId]);
      // harvest if ready
      if (readyMap[target.id]) {
        harvestBuildings([target], "Harvest", true, true);
      }
      refundResources(delta);
      setLayout((prev) => prev.filter((p) => p.id !== target.id));
      setReadyMap((prev) => {
        const next = { ...prev };
        delete next[target.id];
        return next;
      });
      setStatus(
        `${refundMode ? "Refunded" : "Sold"} ${libraryMap[target.defId].name}`
      );
      return;
    }

    if (selectedDef) {
      if (!hasPopulationForDef(stats, selectedDef)) {
        updateStatus("Not enough free population.");
        return;
      }
      const adjustedX = Math.min(x, BOARD_WIDTH - selectedDef.width);
      const adjustedY = Math.min(y, BOARD_HEIGHT - selectedDef.height);
      if (
        !isAreaFree(
          layout,
          adjustedX,
          adjustedY,
          selectedDef.width,
          selectedDef.height,
          undefined,
          isCellUnlocked
        )
      ) {
        updateStatus("Blocked or locked area.");
        return;
      }
      if (!canAffordResources(resources, selectedDef.cost)) {
        updateStatus("Not enough resources.");
        return;
      }
      const snapshot = buildSnapshot();
      spendResources(selectedDef.cost);
      const instance = {
        id: nextId.current++,
        defId: selectedDef.defId,
        x: adjustedX,
        y: adjustedY,
        width: selectedDef.width,
        height: selectedDef.height,
      };
      setLayout((prev) => [...prev, instance]);
      setReadyMap((prev) => ({ ...prev, [instance.id]: false }));
      pushHistory(snapshot);
      setStatus(`Placed ${selectedDef.name}`);
      return;
    }

    if (moveMode && target) {
      const snapshot = buildSnapshot();
      setMoveSnapshot(snapshot);
      setLayout((prev) => prev.filter((p) => p.id !== target.id));
      setCarried({
        instance: { ...target, ready: readyMap[target.id] },
        def: libraryMap[target.defId],
      });
      setStatus(`Picked up ${libraryMap[target.defId].name}`);
      return;
    }

    if (
      !moveMode &&
      !sellMode &&
      !refundMode &&
      !selectedDef &&
      target &&
      readyMap[target.id]
    ) {
      harvestBuildings([target], "Harvest", true);
      return;
    }

    if (
      !moveMode &&
      target &&
      libraryMap[target.defId]?.category === "goods"
    ) {
      const def = libraryMap[target.defId];
      setGoodsModal({ def });
    }
  };

  const handleUnlockRegion = (idx, method, goodKey) => {
    const row = Math.floor(idx / REGION_COLS);
    const col = idx % REGION_COLS;
    if (REGION_MASK[row][col] === "N") return;
    if (!method) {
      const hasAnyGoodEnough = GOODS_TYPES.some((g) =>
        canAffordSingleGood(resources.goods, g, currentGoodsCost)
      );
      const hasGoodsBuilding = layout.some(
        (inst) => libraryMap[inst.defId]?.category === "goods"
      );
      setUnlockChoice({
        idx,
        goodsCost: currentGoodsCost,
        shardCost: currentShardCost,
        allowGoods: hasAnyGoodEnough || hasGoodsBuilding,
        allowShards: (resources.shards ?? 0) >= currentShardCost,
      });
      setUnlockGoodSelect(null);
      return;
    }
    if (method === "goods") {
      if (!canAffordSingleGood(resources.goods, goodKey, currentGoodsCost)) {
        const need = currentGoodsCost - (resources.goods[goodKey] ?? 0);
        const candidateInstance = layout.find(
          (inst) =>
            libraryMap[inst.defId]?.category === "goods" &&
            libraryMap[inst.defId]?.produces === goodKey
        );
        if (!candidateInstance) {
          updateStatus("Need more goods of that type to unlock.");
          return;
        }
        const buildingDef = libraryMap[candidateInstance.defId];
        const options = computePurchasePlans(buildingDef, need);
        if (!options.length) {
          updateStatus("No purchase options available.");
          return;
        }
        setFastBuyModal({
          goodKey,
          goodsCost: currentGoodsCost,
          options,
          buildingDef,
        });
        setFastBuyTarget(idx);
        return;
      }
      const snapshot = buildSnapshot();
      pushHistory(snapshot);
      adjustGoods(goodKey, -currentGoodsCost);
      setGoodsUnlocks((prev) => prev + 1);
      setUnlockedRegions((prev) =>
        prev.map((val, i) => (i === idx ? true : val))
      );
    } else {
      if ((resources.shards ?? 0) < currentShardCost) {
        updateStatus("Need more shards to unlock.");
        return;
      }
      const snapshot = buildSnapshot();
      pushHistory(snapshot);
      setResources((prev) => ({
        ...prev,
        shards: prev.shards - currentShardCost,
      }));
      setShardUnlocks((prev) => prev + 1);
      setUnlockedRegions((prev) =>
        prev.map((val, i) => (i === idx ? true : val))
      );
    }
    setFastBuyTarget(null);
    setUnlockChoice(null);
    setUnlockGoodSelect(null);
  };

  const toggleMove = () => {
    pushHistory(buildSnapshot());
    setMoveMode((prev) => {
      const next = !prev;
      if (next) {
        setSellMode(false);
        setRefundMode(false);
        setSelectedBuildingId(null);
      }
      if (!next) {
        setCarried(null);
        setMoveSnapshot(null);
      }
      return next;
    });
  };

  const toggleSell = () => {
    pushHistory(buildSnapshot());
    setSellMode((prev) => {
      const next = !prev;
      if (next) {
        setMoveMode(false);
        setRefundMode(false);
        setSelectedBuildingId(null);
      }
      return next;
    });
  };

  const toggleRefund = () => {
    pushHistory(buildSnapshot());
    setRefundMode((prev) => {
      const next = !prev;
      if (next) {
        setMoveMode(false);
        setSellMode(false);
        setSelectedBuildingId(null);
      }
      return next;
    });
  };

  const handleGoodsPurchase = (def, amount) => {
    const cost = def.goodsCost?.[amount];
    if (!cost) return;
    if (
      resources.coins < (cost.coins ?? 0) ||
      resources.supplies < (cost.supplies ?? 0)
    ) {
      updateStatus("Not enough coins or supplies.");
      return;
    }
    const snapshot = buildSnapshot();
    pushHistory(snapshot);
    spendResources(cost);
    adjustGoods(def.produces, Number(amount));
    setGoodsModal(null);
  };

  const handleFastBuy = (option) => {
    if (!fastBuyModal || fastBuyTarget === null) return;
    const goodKey = fastBuyModal.goodKey;
    const goodsCost = fastBuyModal.goodsCost;
    const totalCoins = option.plan.reduce(
      (sum, p) => sum + (p.cost.coins ?? 0),
      0
    );
    const totalSupplies = option.plan.reduce(
      (sum, p) => sum + (p.cost.supplies ?? 0),
      0
    );
    if (resources.coins < totalCoins || resources.supplies < totalSupplies) {
      updateStatus("Not enough coins or supplies for fast buy.");
      return;
    }
    const goodsAfterPurchase =
      (resources.goods[goodKey] ?? 0) + option.totalAmount;
    if (goodsAfterPurchase < goodsCost) {
      updateStatus("Fast buy plan insufficient.");
      return;
    }
    const snapshot = buildSnapshot();
    pushHistory(snapshot);
    spendResources({ coins: totalCoins, supplies: totalSupplies });
    adjustGoods(goodKey, option.totalAmount - goodsCost);
    setUnlockedRegions((prev) =>
      prev.map((val, i) => (i === fastBuyTarget ? true : val))
    );
    setGoodsUnlocks((prev) => prev + 1);
    setFastBuyModal(null);
    setFastBuyTarget(null);
  };

  const finishProductions = () => {
    const snapshot = buildSnapshot();
    pushHistory(snapshot);
    setReadyMap(layout.reduce((acc, b) => ({ ...acc, [b.id]: true }), {}));
  };

  const harvestAll = () => {
    const readyOnes = layout.filter((b) => readyMap[b.id]);
    if (readyOnes.length > 0) {
      harvestBuildings(readyOnes, "Partial Harvest");
    } else {
      harvestBuildings(layout, "Full Harvest");
    }
  };

  const confirmHarvest = () => {
    setHarvestModal(null);
  };

  const cancelHarvest = () => {
    setHarvestModal(null);
  };

  useEffect(() => {
    const onKey = (e) => {
      if (e.key === "Escape" && moveSnapshot) {
        applySnapshot(moveSnapshot);
        setCarried(null);
        setMoveSnapshot(null);
        setMoveMode(false);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [moveSnapshot, applySnapshot]);

  const previewDef = carried?.def ?? selectedDef;
  const previewOrigin = useMemo(() => {
    if (!hoverCell || !previewDef) return null;
    return {
      x: Math.min(hoverCell.x, BOARD_WIDTH - previewDef.width),
      y: Math.min(hoverCell.y, BOARD_HEIGHT - previewDef.height),
      width: previewDef.width,
      height: previewDef.height,
      color: categoryColors[previewDef.category],
    };
  }, [hoverCell, previewDef]);

  const stats = computeStats(layout, libraryMap);
  const happyInfo = happinessTier(
    stats.happinessProvided,
    stats.happinessRequired
  );

  const computeBuildingHarvest = (inst) => {
    const def = libraryMap[inst.defId];
    if (!def) return { coins: 0, supplies: 0, chronos: 0, goods: {} };
    const happyMulti = stats.happyMulti ?? 1;
    const coinMulti = 1 + (stats.coinBoost ?? 0) + (happyMulti - 1);
    const supplyMulti = 1 + (stats.supplyBoost ?? 0) + (happyMulti - 1);
    const goods = {};
    switch (def.category) {
      case "housing": {
        const prod = def.production ?? {};
        return {
          coins: Math.round((prod.coins ?? 0) * coinMulti),
          supplies: Math.round((prod.supplies ?? 0) * supplyMulti),
          chronos: Math.round((prod.chronos ?? 0) * happyMulti),
          goods,
        };
      }
      case "production": {
        const prod = def.production ?? {};
        return {
          coins: Math.round((prod.coins ?? 0) * coinMulti),
          supplies: Math.round((prod.supplies ?? 0) * supplyMulti),
          chronos: Math.round((prod.chronos ?? 0) * happyMulti),
          goods,
        };
      }
      case "culture": {
        const chrono = def.production?.chronos ?? def.chronos ?? 0;
        return {
          coins: 0,
          supplies: 0,
          chronos: Math.round(chrono * happyMulti),
          goods,
        };
      }
      case "goods": {
        const amounts = def.goodsCost
          ? Object.keys(def.goodsCost).map((k) => Number(k))
          : [];
        const best = amounts.length ? Math.max(...amounts) : 0;
        if (def.produces && best) goods[def.produces] = best;
        return { coins: 0, supplies: 0, chronos: 0, goods };
      }
      case "townhall": {
        const prod = def.production ?? {};
        return {
          coins: prod.coins ?? 0,
          supplies: prod.supplies ?? 0,
          chronos: prod.chronos ?? 0,
          goods,
        };
      }
      default:
        return { coins: 0, supplies: 0, chronos: 0, goods };
    }
  };

  const harvestBuildings = (
    instances,
    label = "Harvest",
    skipPopup = false,
    skipHistory = false
  ) => {
    if (!instances.length) return;
    const snapshot = skipHistory ? null : buildSnapshot();
    if (!skipHistory) pushHistory(snapshot);
    const total = { coins: 0, supplies: 0, chronos: 0, goods: {} };
    instances.forEach((inst) => {
      const delta = computeBuildingHarvest(inst);
      total.coins += delta.coins ?? 0;
      total.supplies += delta.supplies ?? 0;
      total.chronos += delta.chronos ?? 0;
      GOODS_TYPES.forEach((g) => {
        total.goods[g] = (total.goods[g] ?? 0) + (delta.goods[g] ?? 0);
      });
    });
    setResources((prev) => ({
      ...prev,
      coins: prev.coins + total.coins,
      supplies: prev.supplies + total.supplies,
      chronos: prev.chronos + total.chronos,
      goods: GOODS_TYPES.reduce(
        (acc, g) => ({
          ...acc,
          [g]: (prev.goods[g] ?? 0) + (total.goods[g] ?? 0),
        }),
        {}
      ),
    }));
    const harvestedIds = instances.map((i) => i.id);
    setReadyMap((prev) => {
      const next = { ...prev };
      harvestedIds.forEach((id) => {
        next[id] = false;
      });
      return next;
    });
    if (!skipPopup) {
      setHarvestModal({
        delta: total,
        result: {
          coins: resources.coins + total.coins,
          supplies: resources.supplies + total.supplies,
          chronos: resources.chronos + total.chronos,
          goods: GOODS_TYPES.reduce(
            (acc, g) => ({
              ...acc,
              [g]: (resources.goods[g] ?? 0) + (total.goods[g] ?? 0),
            }),
            {}
          ),
        },
        title: label,
      });
    }
  };
  const {
    currentGoodsCost,
    currentShardCost,
    neighborUnlocked,
    hasAnyGoodsProducer,
    hasAnyGoodsEnough,
    canAnyUnlock,
  } = useRegionAccess({
    unlockedRegions,
    goodsUnlocks,
    shardUnlocks,
    resources,
    layout,
    libraryMap,
  });
  const viewRotation =
    viewMode === "right"
      ? "-90deg"
      : viewMode === "diagonal"
      ? "-45deg"
      : "0deg";

  const boardTransformClass = `view-${viewMode}`;
  const unlockedCoords = unlockedRegions
    .map((flag, idx) =>
      flag
        ? { row: Math.floor(idx / REGION_COLS), col: idx % REGION_COLS }
        : null
    )
    .filter(Boolean);
  const minCol =
    unlockedCoords.length > 0
      ? Math.min(...unlockedCoords.map((c) => c.col))
      : 0;
  const maxCol =
    unlockedCoords.length > 0
      ? Math.max(...unlockedCoords.map((c) => c.col))
      : 0;
  const minRow =
    unlockedCoords.length > 0
      ? Math.min(...unlockedCoords.map((c) => c.row))
      : 0;
  const maxRow =
    unlockedCoords.length > 0
      ? Math.max(...unlockedCoords.map((c) => c.row))
      : 0;
  const viewColStart = minCol * REGION_SIZE;
  const viewColEnd = (maxCol + 1) * REGION_SIZE;
  const viewRowStart = minRow * REGION_SIZE;
  const viewRowEnd = (maxRow + 1) * REGION_SIZE;
  const viewWidth = viewColEnd - viewColStart;
  const viewHeight = viewRowEnd - viewRowStart;

  const CELL_SIZE_PX = 36; // adjust this if your Board uses a different cell size

  const baseWidthPx = viewWidth * CELL_SIZE_PX;
  const baseHeightPx = viewHeight * CELL_SIZE_PX;

  let rotatedWidthPx = baseWidthPx;
  if (viewMode === "right") {
    // 90° CCW → use the vertical height as the horizontal span
    rotatedWidthPx = baseHeightPx;
  } else if (viewMode === "diagonal") {
    // 45° CCW → width ≈ (w + h) / sqrt(2)
    rotatedWidthPx = (baseWidthPx + baseHeightPx) / Math.SQRT2;
  }

  const toolbarOffsetPx = rotatedWidthPx - baseWidthPx;

  // Main board
  const boardTransform =
    viewMode === "right"
      ? // 90° CCW – this version was already good
        "rotate(-90deg) translateX(-100%)"
      : viewMode === "diagonal"
      ? // 45° CCW – rotate first, then scale, THEN push it down
        "rotate(-45deg) translate(-300px, 300px)"
      : "none";

  // Regions mini-map
  const regionTransform =
    viewMode === "right"
      ? // 90° CCW mini-map – rotate like the main map, then nudge UP
        "rotate(-90deg) translate(0px, 0px)"
      : viewMode === "diagonal"
      ? // 45° CCW mini-map – simple rotate/scale, stays inside sidebar
        "rotate(-45deg) scale(0.8) translate(10px, -30px)"
      : "none";

  return (
    <div className="page layout-row">
      <ShopSidebar
        selectedCategory={selectedCategory}
        setSelectedCategory={setSelectedCategory}
        setSelectedBuildingId={setSelectedBuildingId}
        resources={resources}
        stats={stats}
        viewMode={viewMode}
        regionTransform={regionTransform}
        unlockedRegions={unlockedRegions}
        regionMask={REGION_MASK}
        neighborUnlocked={neighborUnlocked}
        currentGoodsCost={currentGoodsCost}
        currentShardCost={currentShardCost}
        canAnyUnlock={canAnyUnlock}
        handleUnlockRegion={handleUnlockRegion}
        REGION_COLS={REGION_COLS}
        onResetModes={resetModes}
      />

      <div className="content-column">
        <TopBar
          resources={resources}
          stats={stats}
          happyInfo={happyInfo}
          viewMode={viewMode}
          setViewMode={setViewMode}
        />
        <div className="workspace">
          <div className="board-area">
            <Board
              viewRotation={viewRotation}
              boardTransform={boardTransform}
              viewWidth={viewWidth}
              viewHeight={viewHeight}
              viewColStart={viewColStart}
              viewRowStart={viewRowStart}
              previewOrigin={previewOrigin}
              isCellUnlocked={isCellUnlocked}
              handleCellClick={handleCellClick}
              setHoverCell={setHoverCell}
              layout={layout}
              libraryMap={libraryMap}
              categoryColors={categoryColors}
              boardTransformClass={boardTransformClass}
              readyMap={readyMap}
            />
            {status && <div className="status">{status}</div>}
            {carried && (
              <div className="carry-banner">
                Carrying {carried.def.name} - place, swap, or trash. Press Esc
                to cancel.
              </div>
            )}
          </div>
          <ActionToolbar
            moveMode={moveMode}
            onToggleMove={toggleMove}
            sellMode={sellMode}
            refundMode={refundMode}
            onToggleSell={toggleSell}
            onToggleRefund={toggleRefund}
            onUndo={undoWithCleanup}
            onRedo={redoWithCleanup}
            finishProductions={finishProductions}
            harvestAll={harvestAll}
            canUndo={!!undoStack.length}
            canRedo={!!redoStack.length}
            onSave={handleSaveState}
            onLoad={handleLoadState}
            saves={saves}
            loadName={loadName}
            setLoadName={setLoadName}
            toolbarOffset={toolbarOffsetPx}
            onDeleteSave={(name) => {
              deleteSave(name);
              setLoadName((prev) => (prev === name ? "" : prev));
            }}
          />
        </div>
      </div>
      {unlockChoice && (
        <div className="modal">
          <div className="modal-card">
            <h3>Unlock Region</h3>
            <div className="modal-body">
              <button
                onClick={() => {
                  if (!unlockChoice.allowGoods) return;
                  setUnlockGoodSelect({
                    idx: unlockChoice.idx,
                    goodsCost: unlockChoice.goodsCost,
                  });
                  setUnlockChoice(null);
                }}
                disabled={!unlockChoice.allowGoods}
              >
                Goods ({unlockChoice.goodsCost})
              </button>
              <button
                onClick={() => handleUnlockRegion(unlockChoice.idx, "shards")}
                disabled={!unlockChoice.allowShards}
              >
                Shards ({unlockChoice.shardCost})
              </button>
            </div>
            <div className="modal-actions">
              <button onClick={() => setUnlockChoice(null)}>Cancel</button>
            </div>
          </div>
        </div>
      )}

      {unlockGoodSelect && (
        <div className="modal">
          <div className="modal-card">
            <h3>Choose good</h3>
            <div className="modal-body">
              {GOODS_TYPES.map((g) => {
                const haveEnough = canAffordSingleGood(
                  resources.goods,
                  g,
                  unlockGoodSelect.goodsCost
                );
                const hasProducer = layout.some(
                  (inst) =>
                    libraryMap[inst.defId]?.category === "goods" &&
                    libraryMap[inst.defId]?.produces === g
                );
                const needsPurchase = !haveEnough && hasProducer;
                const disabled = !haveEnough && !hasProducer;
                return (
                  <button
                    key={g}
                    className={needsPurchase ? "needs-purchase" : ""}
                    disabled={disabled}
                    onClick={() =>
                      handleUnlockRegion(unlockGoodSelect.idx, "goods", g)
                    }
                    title={
                      needsPurchase
                        ? "Will open fast buy options"
                        : "Spend goods"
                    }
                  >
                    <img
                      src={`/goods/${g === "Stein" ? "Backstein" : g}.webp`}
                      alt={g}
                      style={{ width: 20, height: 20, marginRight: 6 }}
                    />
                    {g} ({resources.goods[g] ?? 0}/{unlockGoodSelect.goodsCost})
                  </button>
                );
              })}
            </div>
            <div className="modal-actions">
              <button onClick={() => setUnlockGoodSelect(null)}>Cancel</button>
            </div>
          </div>
        </div>
      )}

      {harvestModal && (
        <div className="modal">
          <div className="modal-card">
            <h3>{harvestModal.title || "Harvest Result"}</h3>
            <div className="modal-body">
              <div>
                Changes: +{harvestModal.delta.coins} coins, +
                {harvestModal.delta.supplies} supplies, +
                {harvestModal.delta.chronos} chronos
              </div>
              <div>
                Goods: {formatGoods(harvestModal.delta.goods, GOODS_TYPES)}
              </div>
              <div>
                Totals: {harvestModal.result.coins} coins /{" "}
                {harvestModal.result.supplies} supplies /{" "}
                {harvestModal.result.chronos} chronos
              </div>
              <div>
                Goods Totals:{" "}
                {formatGoods(harvestModal.result.goods, GOODS_TYPES)}
              </div>
            </div>
            <div className="modal-actions">
              <button onClick={confirmHarvest}>Okay</button>
              <button onClick={cancelHarvest}>Cancel</button>
            </div>
          </div>
        </div>
      )}

      {goodsModal && (
        <div className="modal">
          <div className="modal-card">
            <h3>Buy {goodsModal.def.produces}</h3>
            <div className="modal-body">
              {Object.entries(goodsModal.def.goodsCost || {}).map(
                ([amt, cost]) => (
                  <button
                    key={amt}
                    onClick={() => handleGoodsPurchase(goodsModal.def, amt)}
                    style={{ width: "100%", marginBottom: 6 }}
                  >
                    +{amt} for {cost.coins ?? 0} coins / {cost.supplies ?? 0}{" "}
                    supplies
                  </button>
                )
              )}
            </div>
            <div className="modal-actions">
              <button onClick={() => setGoodsModal(null)}>Close</button>
            </div>
          </div>
        </div>
      )}

      {fastBuyModal && (
        <div className="modal">
          <div className="modal-card">
            <h3>Fast buy {fastBuyModal.goodKey}</h3>
            <div className="modal-body">
              <div>
                Need: {fastBuyModal.goodsCost} {fastBuyModal.goodKey}
              </div>
              {(fastBuyModal.options || []).map((opt, idx) => {
                const coins = opt.plan.reduce(
                  (s, p) => s + (p.cost.coins ?? 0),
                  0
                );
                const supplies = opt.plan.reduce(
                  (s, p) => s + (p.cost.supplies ?? 0),
                  0
                );
                return (
                  <button
                    key={idx}
                    onClick={() => handleFastBuy(opt)}
                    style={{ width: "100%", marginBottom: 6 }}
                  >
                    {opt.label}: buy {opt.totalAmount} for {coins} coins /{" "}
                    {supplies} supplies
                  </button>
                );
              })}
            </div>
            <div className="modal-actions">
              <button
                onClick={() => {
                  setFastBuyModal(null);
                  setFastBuyTarget(null);
                }}
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;

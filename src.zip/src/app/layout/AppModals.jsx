import { UnlockRegionModal } from "../../components/modals/UnlockRegionModal";
import { ChooseGoodModal } from "../../components/modals/ChooseGoodModal";
import { GoodsPurchaseModal } from "../../components/modals/GoodsPurchaseModal";
import { UnitsPurchaseModal } from "../../components/modals/UnitsPurchaseModal";
import { FastBuyModal } from "../../components/modals/FastBuyModal";
import { HarvestModal } from "../../components/modals/HarvestModal";
import { SmartHarvestModal } from "../../components/modals/SmartHarvestModal";
import { SmartInvestModal } from "../../components/modals/SmartInvestModal";
import { SupplyOptimizerModal } from "../../components/modals/SupplyOptimizerModal";
import { HelpModal } from "../../components/modals/HelpModal";
import { SettingsModal } from "../../components/modals/SettingsModal";
import { EditGoodModal } from "../../components/modals/EditGoodModal";
import { EditUnitModal } from "../../components/modals/EditUnitModal";
import { WorstRemovalModal } from "../../components/modals/WorstRemovalModal";
import { ExportSavesModal } from "../../components/modals/ExportSavesModal";
import { ImportSavesModal } from "../../components/modals/ImportSavesModal";
import { LoadSavesModal } from "../../components/modals/LoadSavesModal";
import { OnlineLibraryModal } from "../../components/modals/OnlineLibraryModal";
import { PastEditWarningModal } from "../../components/modals/PastEditWarningModal";
import { EditResourceModal } from "../../components/modals/EditResourceModal";
import { useTutorial } from "../../context/TutorialContext";
import { TUTORIAL_EXAMPLE_SAVE_NAME } from "../../tutorial/tutorialSteps";
import "../../components/modals/modals.css";
import "../../components/modals/LoadSavesModal.css";
import "../../components/modals/OnlineLibraryModal.css";
import "../../components/common/SavefileCard.css";

// Centralizes modal rendering to keep the root component lean.
export function AppModals({
  controller,
  settingsModalOpen,
  settingsInitialTab,
  setSettingsModalOpen,
  viewMode,
  setViewMode,
  toolbarPosition,
  setToolbarPosition,
  boardScale,
  setBoardScale,
  warnDeleteSingleAction,
  setWarnDeleteSingleAction,
  warnDeleteSubtree,
  setWarnDeleteSubtree,
  saveAccountToCloud,
  canCloudSave,
  cloudProfile,
}) {
  const { fireEvent } = useTutorial();

  const {
    unlockChoice,
    setUnlockChoice,
    unlockGoodSelect,
    setUnlockGoodSelect,
    resources,
    config,
    currentGoodsCost,
    handleUnlockRegion,
    handleAdminLockRegion,
    layout,
    libraryMap,
    harvestModal,
    confirmHarvest,
    cancelHarvest,
    smartHarvestModal,
    confirmSmartHarvest,
    smartInvestModal,
    applySmartInvestResult,
    continueSmartInvest,
    closeSmartInvestModal,
    supplyOptimizerModalOpen,
    supplyOptimizerState,
    stepSupplyOptimizerOnce,
    stepSupplyOptimizerFew,
    finishSupplyOptimizer,
    closeSupplyOptimizer,
    goodsModal,
    setGoodsModal,
    handleGoodsPurchase,
    unitModal,
    setUnitModal,
    handleUnitPurchase,
    editUnitModal,
    applyUnitEdit,
    cancelEditUnit,
    editGoodModal,
    applyGoodEdit,
    cancelEditGood,
    editResourceModal,
    applyResourceEdit,
    cancelEditResource,
    fastBuyModal,
    handleFastBuy,
    setFastBuyModal,
    setFastBuyTarget,
    helpModal,
    setHelpModal,
    updateConfig,
    applyStartBonusToCheckpoints,
    exportModal,
    importModal,
    loadSavesModal,
    onlineLibraryModal,
    setExportModal,
    setImportModal,
    setLoadSavesModal,
    setOnlineLibraryModal,
    visibleSaves,
    saves,
    loadName,
    handleExportSelected,
    handleExportSavefile,
    handleUploadSharedSave,
    handleRenameSavefile,
    handleDeleteSavefile,
    handleImportSelected,
    handleLoadState,
    worstModal,
    setWorstModal,
    pastEditModal,
    handleCopyAndEnableEdit,
    handleEnableEditFromPast,
    closePastEditModal,
    hasUnsavedChanges,
    userConfig,
  } = controller;

  const handleHarvestModalClose = (fn) => {
    fn?.();
    fireEvent("harvest-popup-closed");
  };

  const handleLoadFromModal = (name) => {
    handleLoadState?.(name);
    if (name === TUTORIAL_EXAMPLE_SAVE_NAME) {
      fireEvent("loadExampleSave", { name });
    }
  };

  return (
    <>
      <UnlockRegionModal
        unlockChoice={unlockChoice}
        onChooseGoods={(choice) => {
          if (!choice) return;
          if (choice.mode === "lock") {
            handleAdminLockRegion?.(choice.idx, "goods");
            return;
          }
          if (choice.adminMode) {
            handleUnlockRegion(choice.idx, "goods");
            return;
          }
          setUnlockGoodSelect({ idx: choice.idx, goodsCost: choice.goodsCost });
          setUnlockChoice(null);
        }}
        onChooseShards={(choice) => {
          if (!choice) return;
          if (choice.mode === "lock") {
            handleAdminLockRegion?.(choice.idx, "shards");
            return;
          }
          handleUnlockRegion(choice.idx, "shards");
        }}
        onCancel={() => setUnlockChoice(null)}
        shards={resources?.shards ?? 0}
        config={config}
      />

      <ChooseGoodModal
        unlockGoodSelect={unlockGoodSelect}
        goods={resources.goods}
        layout={layout}
        libraryMap={libraryMap}
        onUnlockWithGood={(idx, goodKey) =>
          handleUnlockRegion(idx, "goods", goodKey)
        }
        onCancel={() => setUnlockGoodSelect(null)}
      />

      <HarvestModal
        harvestModal={harvestModal}
        onConfirm={() => handleHarvestModalClose(confirmHarvest)}
        onCancel={() => handleHarvestModalClose(cancelHarvest)}
      />
      <SmartHarvestModal
        smartHarvestModal={smartHarvestModal}
        onConfirm={confirmSmartHarvest}
      />
      <SmartInvestModal
        smartInvestModal={smartInvestModal}
        onClose={closeSmartInvestModal}
        onApplyResult={applySmartInvestResult}
        onContinue={continueSmartInvest}
      />
      <SupplyOptimizerModal
        open={!!supplyOptimizerModalOpen}
        onClose={closeSupplyOptimizer}
        optimizerState={supplyOptimizerState}
        onStepOnce={stepSupplyOptimizerOnce}
        onStepFew={stepSupplyOptimizerFew}
        onFinish={finishSupplyOptimizer}
      />

      <GoodsPurchaseModal
        goodsModal={goodsModal}
        goods={resources?.goods}
        currentGoodsCost={currentGoodsCost}
        onPurchase={handleGoodsPurchase}
        onClose={() => setGoodsModal(null)}
      />
      <UnitsPurchaseModal
        unitModal={unitModal}
        onPurchase={handleUnitPurchase}
        onClose={() => setUnitModal(null)}
      />
      <EditUnitModal
        modal={editUnitModal}
        onSave={applyUnitEdit}
        onClose={cancelEditUnit}
      />
      <EditGoodModal
        modal={editGoodModal}
        onSave={(val) => applyGoodEdit(val, false)}
        onSaveAll={(val) => applyGoodEdit(val, true)}
        onClose={cancelEditGood}
      />
      <EditResourceModal
        modal={editResourceModal}
        onSave={applyResourceEdit}
        onClose={cancelEditResource}
      />

      <FastBuyModal
        fastBuyModal={fastBuyModal}
        onFastBuy={handleFastBuy}
        onCancel={() => {
          setFastBuyModal(null);
          setFastBuyTarget(null);
        }}
      />
      <HelpModal open={!!helpModal} onClose={() => setHelpModal(false)} />
      <SettingsModal
        open={!!settingsModalOpen}
        initialTab={settingsInitialTab}
        onClose={() => setSettingsModalOpen(false)}
        config={config}
        onSave={updateConfig}
        onPreviewConfig={updateConfig}
        onApplyStartBonus={applyStartBonusToCheckpoints}
        viewMode={viewMode}
        setViewMode={setViewMode}
        toolbarPosition={toolbarPosition}
        setToolbarPosition={setToolbarPosition}
        boardScale={boardScale}
        setBoardScale={setBoardScale}
        warnDeleteSingleAction={warnDeleteSingleAction}
        setWarnDeleteSingleAction={setWarnDeleteSingleAction}
        warnDeleteSubtree={warnDeleteSubtree}
        setWarnDeleteSubtree={setWarnDeleteSubtree}
        saveAccountToCloud={saveAccountToCloud}
        canCloudSave={canCloudSave}
        cloudProfile={cloudProfile}
      />
      <ExportSavesModal
        open={!!exportModal}
        saves={visibleSaves}
        onClose={() => setExportModal(false)}
        onExport={handleExportSelected}
      />
      <ImportSavesModal
        open={!!importModal}
        onClose={() => setImportModal(false)}
        onImport={handleImportSelected}
      />
      <LoadSavesModal
        open={!!loadSavesModal}
        saves={saves}
        loadName={loadName}
        onClose={() => {
          setLoadSavesModal(false);
          fireEvent("loadMenuClosed");
        }}
        onLoad={handleLoadFromModal}
        onRename={handleRenameSavefile}
        onDelete={handleDeleteSavefile}
        onExport={handleExportSavefile}
        onUploadShared={handleUploadSharedSave}
        canUploadShared={canCloudSave && !!cloudProfile?.username}
        onImport={handleImportSelected}
        hasUnsavedChanges={hasUnsavedChanges}
        userConfig={userConfig}
      />
      <WorstRemovalModal
        open={!!worstModal}
        data={worstModal}
        onClose={() => setWorstModal(null)}
      />
      <OnlineLibraryModal
        open={!!onlineLibraryModal}
        onClose={() => setOnlineLibraryModal(false)}
        userConfig={userConfig}
        currentUsername={cloudProfile?.username || ""}
        onLoadSharedSave={handleImportSelected}
      />
      <PastEditWarningModal
        open={pastEditModal}
        onCopyAndContinue={handleCopyAndEnableEdit}
        onContinue={handleEnableEditFromPast}
        onCancel={closePastEditModal}
        currentName={loadName}
      />
    </>
  );
}

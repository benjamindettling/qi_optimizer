import { RegionBadge } from "./RegionBadge";

export function RegionsPanel({
  viewMode,
  regionTransform,
  unlockedRegions,
  regionMask,
  neighborUnlocked,
  currentGoodsCost,
  currentShardCost,
  canAnyUnlock,
  handleUnlockRegion,
  REGION_COLS,

  debugRegions = false,
  onToggleDebugRegions,
  onDebugUnlockRegion,
  onDebugLockRegion,
}) {
  return (
    <div className="regions">
      <div className="regions-title-row">
        <div className="regions-title">Regions</div>

        {/* Keep this always present so layout never changes */}
        <label className="regions-debug">
          <input
            type="checkbox"
            checked={debugRegions}
            onChange={(e) => onToggleDebugRegions?.(e.target.checked)}
          />
          Debug
        </label>
      </div>

      <div className={`region-frame ${viewMode ? `view-${viewMode}` : ""}`}>
        <div
          className="region-grid"
          style={{
            gridTemplateColumns: `repeat(${REGION_COLS}, 1fr)`,
            transform: regionTransform,
          }}
        >
          {unlockedRegions.map((flag, idx) => {
            const row = Math.floor(idx / REGION_COLS);
            const col = idx % REGION_COLS;

            const mask = regionMask?.[row]?.[col];
            const isVoid = mask === "N";
            const isBase = mask === "S";
            const isNeighbor =
              typeof neighborUnlocked === "function"
                ? neighborUnlocked(idx)
                : !!neighborUnlocked?.[idx];

            return (
              <RegionBadge
                key={idx}
                unlocked={!!flag}
                isNeighbor={isNeighbor}
                isVoid={isVoid}
                isBase={isBase}
                canUnlock={canAnyUnlock}
                onUnlock={() => handleUnlockRegion?.(idx)}
                debugMode={debugRegions}
                onDebugUnlock={() => onDebugUnlockRegion?.(idx)}
                onDebugLock={() => onDebugLockRegion?.(idx, isBase)}
              />
            );
          })}
        </div>
      </div>

      <div className="region-note">
        Costs scale per unlock. Current: {currentGoodsCost} goods or{" "}
        {currentShardCost} shards.
      </div>
    </div>
  );
}

import { RegionBadge } from "./RegionBadge";

export function RegionsPanel({
  viewMode,
  regionTransform,
  unlockedRegions,
  regionMask,
  neighborUnlocked,
  currentGoodsCost,
  currentShardCost,
  canAnyUnlock,
  handleUnlockRegion,
  REGION_COLS,
}) {
  return (
    <div className="regions">
      <div className="regions-title">Regions</div>
      <div className={`region-frame view-${viewMode}`} style={{ transform: regionTransform }}>
        <div className="region-grid" style={{ gridTemplateColumns: `repeat(${REGION_COLS}, 1fr)` }}>
          {unlockedRegions.map((flag, idx) => (
            <RegionBadge
              key={idx}
              unlocked={flag}
              isNeighbor={neighborUnlocked(idx)}
              isVoid={regionMask[Math.floor(idx / REGION_COLS)][idx % REGION_COLS] === "N"}
              canUnlock={canAnyUnlock}
              onUnlock={() => handleUnlockRegion(idx)}
            />
          ))}
        </div>
      </div>
      <div className="region-note">
        Costs scale per unlock. Current: {currentGoodsCost} goods or {currentShardCost} shards.
      </div>
    </div>
  );
}

export function ActionToolbar({
  moveMode,
  sellMode,
  refundMode,
  onToggleMove,
  onToggleSell,
  onToggleRefund,
  onUndo,
  onRedo,
  finishProductions,
  harvestAll,
  canUndo,
  canRedo,
  onSave,
  onLoad,
  saves,
  loadName,
  setLoadName,
  toolbarOffset = 0,
  onDeleteSave,
}) {
  const saveKeys = Object.keys(saves);
  return (
    <div
      className="actions-column"
      style={{ marginLeft: `${toolbarOffset}px` }}
    >
      <div style={{ display: "flex", gap: 6 }}>
        <button
          onClick={onToggleMove}
          className={moveMode ? "active" : ""}
          style={{ background: "#2d7a42", borderColor: "#2d7a42", flex: 1 }}
          title="Move"
        >
          ↕↔
        </button>
        <button
          onClick={onToggleSell}
          className={sellMode ? "active" : ""}
          style={{ background: "#8b1d1d", borderColor: "#b02727", flex: 1 }}
          title="Sell"
        >
          🗑
        </button>
      </div>
      <div style={{ display: "flex", gap: 6 }}>
        <button onClick={onUndo} disabled={!canUndo}>
          Undo
        </button>
        <button onClick={onRedo} disabled={!canRedo}>
          Redo
        </button>
      </div>
      <button
        onClick={onToggleRefund}
        className={refundMode ? "active" : ""}
        style={{ background: "#b02727", borderColor: "#d23c3c" }}
      >
        Refund
      </button>

      <button
        onClick={finishProductions}
        style={{ background: "#b8860b", borderColor: "#b8860b" }}
      >
        Finish Productions
      </button>
      <button onClick={harvestAll}>Harvest All</button>
      <button onClick={onSave}>Save</button>
      <div>
        <select
          value={loadName}
          onChange={(e) => setLoadName(e.target.value)}
          style={{ width: "100%" }}
        >
          <option value="">Load state...</option>
          {saveKeys.map((k) => (
            <option key={k} value={k}>
              {k}
            </option>
          ))}
        </select>
        <button
          onClick={() => {
            if (loadName) onLoad(loadName);
          }}
          disabled={!loadName}
          style={{ marginTop: 4 }}
        >
          Load
        </button>
        {saveKeys.map((k) => (
          <div
            key={`del-${k}`}
            style={{ marginTop: 4, display: "flex", gap: 6 }}
          >
            <span style={{ flex: 1 }}>{k}</span>
            <button
              style={{ background: "#8b1d1d", borderColor: "#b02727" }}
              onClick={() => onDeleteSave && onDeleteSave(k)}
              title={`Delete save ${k}`}
            >
              Delete
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

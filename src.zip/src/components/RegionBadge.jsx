export function RegionBadge({ unlocked, isNeighbor, isVoid, canUnlock, onUnlock }) {
  if (isVoid) return <span className="region void" />;
  if (unlocked) return <span className="region unlocked" />;
  return (
    <div className={`region locked ${isNeighbor ? "neighbor" : ""}`}>
      {isNeighbor && (
        <button className="region-unlock-btn" disabled={!canUnlock} onClick={onUnlock} title="Unlock region" />
      )}
    </div>
  );
}

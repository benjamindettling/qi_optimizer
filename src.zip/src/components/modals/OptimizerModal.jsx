import { useEffect } from "react";
import { useLang } from "../../context/LanguageContext";
import { T } from "../../i18n/translations";
import { formatNumber } from "../../utils/formatNumber";

const formatTemplate = (template, values = {}) =>
  Object.entries(values).reduce(
    (acc, [key, value]) => acc.replaceAll(`{${key}}`, String(value)),
    template,
  );

const MoneySetupCard = ({ setup, t }) => (
  <div className="optimizer-card">
    <div className="optimizer-card-title">{t("moneyOptimizerTitle")}</div>
    {setup ? (
      <div className="optimizer-card-lines">
        <div>
          {t("moneyOptimizerScoreLabel")}: {formatNumber(setup.moneyHarvest ?? 0)}
        </div>
        <div>
          {t("moneyOptimizerStartMH")}: {setup.start_MH ?? 0}
        </div>
        <div>
          {t("moneyOptimizerStartEH")}: {setup.start_EH ?? 0}
        </div>
        <div>
          {t("moneyOptimizerChurches")}: {setup.numb_churches ?? 0}
        </div>
      </div>
    ) : (
      <div className="optimizer-empty">{t("supplyOptimizerNoResult")}</div>
    )}
  </div>
);

const SupplySetupCard = ({ setup, t }) => {
  const buildings = setup?.buildings || [];
  return (
    <div className="optimizer-card">
      <div className="optimizer-card-title">{t("supplyOptimizerModalTitle")}</div>
      {setup ? (
        <div className="optimizer-card-lines">
          <div>
            {t("supplyOptimizerScoreLabel")}: {formatNumber(setup.supplyHarvest ?? 0)}
          </div>
        </div>
      ) : (
        <div className="optimizer-empty">{t("supplyOptimizerNoResult")}</div>
      )}
      {buildings.length > 0 ? (
        <ul className="optimizer-list">
          {buildings.map((entry) => (
            <li key={entry.defId} className="optimizer-item">
              {entry.name} x{entry.count}
            </li>
          ))}
        </ul>
      ) : (
        <div className="optimizer-empty">{t("supplyOptimizerNoBuildings")}</div>
      )}
    </div>
  );
};

export function OptimizerModal({
  open,
  onClose,
  supplyOptimizerState,
  frozenSupplyBestSetup,
  moneyOptimizerState,
  onStepOnce,
  onStepFew,
  onFinish,
  finishLabelKey,
  onNew,
}) {
  const { lang } = useLang();
  const t = (key) => T[key]?.[lang] ?? T[key]?.DE ?? key;

  useEffect(() => {
    if (!open) return undefined;
    const onKeyDown = (event) => {
      if (event.key === "Escape") {
        event.preventDefault();
        onClose?.();
      }
    };
    window.addEventListener("keydown", onKeyDown, true);
    return () => window.removeEventListener("keydown", onKeyDown, true);
  }, [open, onClose]);

  if (!open) return null;

  const supplyPhase = supplyOptimizerState?.phase ?? "idle";
  const moneyPhase = moneyOptimizerState?.phase ?? "idle";
  const supplyDone = supplyPhase === "done";
  const activeRunning = supplyDone
    ? moneyPhase === "running"
    : supplyPhase === "running";
  const isDone = supplyDone && moneyPhase === "done";
  const finishKey = finishLabelKey || "supplyOptimizerFinish";
  const geomEvalCount = moneyOptimizerState?.geomEvalCount ?? 0;
  const harvestEvalCount = moneyOptimizerState?.harvestEvalCount ?? 0;

  let statusLine = "";
  if (activeRunning) {
    if (!supplyDone) {
      const evalCount = supplyOptimizerState?.evalCount ?? 0;
      const evalText =
        evalCount > 0
          ? ` | ${formatTemplate(t("supplyOptimizerEvalCount"), { count: evalCount })}`
          : "";
      statusLine = `${t("supplyOptimizerRunning")}${evalText}`;
    } else {
      statusLine = `${t("supplyOptimizerRunning")} ${formatTemplate(
        t("moneyOptimizerGeomCount"),
        { count: geomEvalCount },
      )} | ${formatTemplate(t("moneyOptimizerHarvestCount"), {
        count: harvestEvalCount,
      })}`;
    }
  } else if (!supplyDone) {
    const evalCount = supplyOptimizerState?.evalCount ?? 0;
    if (evalCount > 0) {
      statusLine = formatTemplate(t("supplyOptimizerEvalCount"), {
        count: evalCount,
      });
    }
  } else if (moneyPhase === "idle") {
    statusLine = t("supplyOptimizerSearchComplete");
  } else if (moneyOptimizerState?.subPhase === "geometry") {
    statusLine = formatTemplate(t("moneyOptimizerGeomCount"), {
      count: geomEvalCount,
    });
  } else {
    statusLine = `${formatTemplate(t("moneyOptimizerGeomCount"), {
      count: geomEvalCount,
    })} | ${formatTemplate(t("moneyOptimizerHarvestCount"), {
      count: harvestEvalCount,
    })}`;
  }

  return (
    <div className="modal">
      <div className="modal-card optimizer-modal">
        <div className="help-header">
          <h3>{t("optimizerModalTitle")}</h3>
          <button onClick={onClose}>{t("supplyOptimizerClose")}</button>
        </div>

        {!activeRunning && (
          <div className="modal-actions optimizer-actions">
            <button onClick={onStepOnce} disabled={isDone}>
              {t("supplyOptimizerOneStep")}
            </button>
            <button onClick={onStepFew} disabled={isDone}>
              {t("supplyOptimizerFewSteps")}
            </button>
            <button onClick={onFinish} disabled={isDone}>
              {t(finishKey)}
            </button>
            <button onClick={onNew}>{t("optimizerNew")}</button>
          </div>
        )}

        {statusLine && <div className="optimizer-status">{statusLine}</div>}
        {isDone && (
          <div className="optimizer-status optimizer-status-done">
            {t("supplyOptimizerSearchComplete")}
          </div>
        )}

        <div className="optimizer-grid">
          <MoneySetupCard setup={moneyOptimizerState?.bestSetup} t={t} />
          <SupplySetupCard setup={frozenSupplyBestSetup} t={t} />
        </div>

        {moneyOptimizerState?.finalResources && (
          <div className="optimizer-final">
            <div className="optimizer-final-title">{t("optimizerFinalResources")}</div>
            <div className="optimizer-final-line">
              {t("optimizerFinalCoins")}:{" "}
              {formatNumber(moneyOptimizerState.finalResources.coins ?? 0)} |{" "}
              {t("optimizerFinalSupplies")}:{" "}
              {formatNumber(moneyOptimizerState.finalResources.supplies ?? 0)} |{" "}
              {t("optimizerFinalChronos")}:{" "}
              {formatNumber(moneyOptimizerState.finalResources.chronos ?? 0)}
            </div>
          </div>
        )}

        <div className="modal-actions">
          <button onClick={onClose}>{t("supplyOptimizerClose")}</button>
        </div>
      </div>
    </div>
  );
}
